# Reptilia (Minecraft Java 26.1.2, Fabric)

Reptiles con su bioma: 5 serpientes (titanoboa miniboss de 200 de vida), 3 cocodrilianos, iguana y gecko,
Ciénaga Reptil, madera de ceiba, escamas, carnes cocinables y 3 armaduras. Pestaña creativa "Reptiles".

## Compilar en GitHub
1. Crea un repo nuevo y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** → workflow `build` → al terminar, descarga el artefacto `reptilia-mod` (el `.jar`).
3. Pon el `.jar` en `mods/` junto con Fabric API `0.155.0+26.1.2`.

## Compatibilidad con el mod de cápsulas
Los reptiles son `Mob` normales y persistentes: la cápsula puede capturarlos y soltarlos.

## Si algo falla
Pega el log de GitHub Actions (compilación) o `latest.log` (juego) y se corrige.
`tools/gen_assets.py` regenera texturas y JSON.
