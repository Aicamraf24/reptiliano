#!/usr/bin/env python3
"""Huevos fértiles (bloques), flora de la Ciénaga Reptil y textos extra. Lo llama gen_assets.py."""
import json, os, random
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src/main/resources")
A = os.path.join(RES, "assets/reptilia")
D = os.path.join(RES, "data/reptilia")
NS = "reptilia"

# id -> (color de la cáscara, color de las manchas, nombre es, nombre en)
EGGS = {
    "titanoboa":      ((196, 186, 140), (78, 68, 38), "titanoboa", "Titanoboa"),
    "anaconda":       ((208, 206, 172), (62, 90, 42), "anaconda", "Anaconda"),
    "king_cobra":     ((226, 216, 186), (124, 108, 62), "cobra real", "King Cobra"),
    "rattlesnake":    ((230, 218, 190), (150, 110, 70), "cascabel", "Rattlesnake"),
    "black_mamba":    ((214, 214, 200), (76, 74, 68), "mamba negra", "Black Mamba"),
    "nile_crocodile": ((222, 214, 176), (86, 102, 62), "cocodrilo del Nilo", "Nile Crocodile"),
    "caiman":         ((214, 220, 184), (52, 94, 50), "caimán", "Caiman"),
    "alligator":      ((226, 224, 200), (42, 54, 46), "aligátor", "Alligator"),
    "iguana":         ((232, 230, 196), (90, 170, 62), "iguana", "Iguana"),
    "gecko":          ((238, 234, 214), (216, 152, 72), "gecko", "Gecko"),
}


def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def clamp(v): return max(0, min(255, int(v)))
def shade(c, d): return tuple(clamp(x + d) for x in c)


def egg_texture(sid, shell, spots, variant):
    rng = random.Random(sid + str(variant))
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
    px = img.load()
    for y in range(16):
        for x in range(16):
            px[x, y] = shade(shell, rng.randint(-7, 7)) + (255,)
    for _ in range(26):
        x, y = rng.randint(0, 15), rng.randint(0, 15)
        px[x, y] = shade(spots, rng.randint(-10, 10)) + (255,)
        if rng.random() < 0.5:
            px[(x + 1) % 16, y] = shade(spots, rng.randint(-10, 10)) + (255,)
    if variant >= 1:   # grietas
        dark = shade(spots, -60)
        n = 3 if variant == 1 else 7
        for i in range(n):
            x, y = rng.randint(1, 14), rng.randint(0, 6)
            for k in range(rng.randint(3, 6) if variant == 2 else rng.randint(2, 4)):
                px[min(15, x + (k % 2)), min(15, y + k)] = dark + (255,)
    out = os.path.join(A, "textures/block", f"{sid}_egg_{variant}.png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out)


def write_eggs():
    # modelo base: huevo en tres cubos apilados
    def face(w, h):
        return {"uv": [0, 0, w, h], "texture": "#egg"}
    def elem(frm, to):
        w, h, d = to[0] - frm[0], to[1] - frm[1], to[2] - frm[2]
        return {"from": frm, "to": to, "faces": {
            "north": face(w, h), "south": face(w, h), "east": face(d, h), "west": face(d, h),
            "up": face(w, d), "down": face(w, d)}}
    wjson(f"{A}/models/block/reptile_egg.json", {
        "textures": {"particle": "#egg"},
        "elements": [elem([5, 0, 5], [11, 2, 11]), elem([4, 2, 4], [12, 8, 12]), elem([5, 8, 5], [11, 10, 11])],
        "display": {"gui": {"rotation": [30, 225, 0], "scale": [1.6, 1.6, 1.6], "translation": [0, -1, 0]}}})
    for sid, (shell, spots, _, _) in EGGS.items():
        for v in range(3):
            egg_texture(sid, shell, spots, v)
            wjson(f"{A}/models/block/{sid}_egg_{v}.json", {
                "parent": f"{NS}:block/reptile_egg", "textures": {"egg": f"{NS}:block/{sid}_egg_{v}"}})
        variants = {}
        for stage in range(10):
            v = 0 if stage <= 3 else (1 if stage <= 6 else 2)
            variants[f"stage={stage}"] = {"model": f"{NS}:block/{sid}_egg_{v}"}
        wjson(f"{A}/blockstates/{sid}_egg.json", {"variants": variants})
        wjson(f"{A}/items/{sid}_egg.json", {"model": {"type": "minecraft:model", "model": f"{NS}:block/{sid}_egg_0"}})
        wjson(f"{D}/loot_table/blocks/{sid}_egg.json", {"type": "minecraft:block", "pools": [{
            "rolls": 1, "bonus_rolls": 0,
            "entries": [{"type": "minecraft:item", "name": f"{NS}:{sid}_egg"}],
            "conditions": [{"condition": "minecraft:survives_explosion"}]}]})


def update_lang():
    for code in ("es_es", "en_us"):
        path = f"{A}/lang/{code}.json"
        lang = json.load(open(path, encoding="utf-8"))
        lang["itemGroup.reptilia.reptiles"] = "Reptilia"
        for sid, (_, _, es, en) in EGGS.items():
            lang[f"block.{NS}.{sid}_egg"] = f"Huevo fértil de {es}" if code == "es_es" else f"Fertile {en} Egg"
        wjson(path, lang)


# ------------------------------------------------------------------ flora
def block_state(name, double=False, props=None):
    st = {"Name": f"minecraft:{name}"}
    if double:
        st["Properties"] = {"half": "lower"}
    if props:
        st["Properties"] = props
    return st


def patch(tries, spread, entries):
    """entries: lista de (bloque, peso, doble)"""
    return {"type": "minecraft:random_patch", "config": {
        "tries": tries, "xz_spread": spread, "y_spread": 3,
        "feature": {
            "feature": {"type": "minecraft:simple_block", "config": {"to_place": {
                "type": "minecraft:weighted_state_provider",
                "entries": [{"weight": w, "data": block_state(n, d)} for n, w, d in entries]}}},
            "placement": [{"type": "minecraft:block_predicate_filter", "predicate": {
                "type": "minecraft:matching_blocks", "blocks": "minecraft:air"}}]}}}


def placed(name, count, extra=None):
    wjson(f"{D}/worldgen/placed_feature/{name}.json", {
        "feature": f"{NS}:{name}",
        "placement": [{"type": "minecraft:count", "count": count}, {"type": "minecraft:in_square"},
                      {"type": "minecraft:heightmap", "heightmap": "MOTION_BLOCKING"}] + (extra or []) +
                     [{"type": "minecraft:biome"}]})


FLORA_ENABLED = False   # pon True para volver a activar la flora nueva del bioma


def write_flora_and_biome():
    if not FLORA_ENABLED:
        # versión segura: la misma lista de vegetación que ya funcionó en el juego, sin flora nueva
        for n in ("reptile_flowers", "reptile_tall_flowers", "reptile_ferns", "reptile_tall_grass"):
            for kind in ("configured_feature", "placed_feature"):
                fp = f"{D}/worldgen/{kind}/{n}.json"
                if os.path.exists(fp):
                    os.remove(fp)
        path = f"{D}/worldgen/biome/reptile_swamp.json"
        biome = json.load(open(path, encoding="utf-8"))
        biome["features"][9] = ["minecraft:patch_grass_normal", "minecraft:patch_waterlily", f"{NS}:ceiba_tree"]
        wjson(path, biome)
        return
    flora = {
        "reptile_flowers": (3, 64, 6, [("blue_orchid", 4, False), ("allium", 2, False), ("azure_bluet", 2, False),
                                       ("pink_tulip", 2, False), ("orange_tulip", 2, False), ("red_tulip", 1, False),
                                       ("cornflower", 2, False), ("lily_of_the_valley", 2, False)]),
        "reptile_tall_flowers": (2, 24, 6, [("peony", 2, True), ("lilac", 2, True), ("rose_bush", 2, True)]),
        "reptile_ferns": (3, 96, 7, [("fern", 4, False), ("large_fern", 3, True)]),
        "reptile_tall_grass": (4, 128, 7, [("tall_grass", 3, True), ("short_grass", 5, False)]),
    }
    for name, (count, tries, spread, entries) in flora.items():
        wjson(f"{D}/worldgen/configured_feature/{name}.json", patch(tries, spread, entries))
        placed(name, count)

    # El bioma: solo UN feature vanilla por paso de vegetación (evita conflictos de orden con otros biomas)
    path = f"{D}/worldgen/biome/reptile_swamp.json"
    biome = json.load(open(path, encoding="utf-8"))
    biome["features"][9] = [f"{NS}:ceiba_tree", f"{NS}:reptile_tall_grass", f"{NS}:reptile_ferns",
                            f"{NS}:reptile_flowers", f"{NS}:reptile_tall_flowers", "minecraft:patch_waterlily"]
    wjson(path, biome)


def write_all():
    write_eggs()
    write_flora_and_biome()
    update_lang()


if __name__ == "__main__":
    write_all()
