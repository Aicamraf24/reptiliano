#!/usr/bin/env python3
"""Genera TODAS las texturas y JSON del mod Reptilia (assets + data).
Uso (desde la raíz del proyecto):  python3 tools/gen_assets.py   (necesita Pillow)
Las medidas de cabezas deben coincidir con ReptileShapes.java.
"""
import json, os, random, math, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src/main/resources")
A = os.path.join(RES, "assets/reptilia")
D = os.path.join(RES, "data/reptilia")
M = os.path.join(RES, "data/minecraft")
NS = "reptilia"
random.seed(26)


def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def clamp(v):
    return max(0, min(255, int(v)))


def shade(c, d):
    return (clamp(c[0] + d), clamp(c[1] + d), clamp(c[2] + d))


# ------------------------------------------------------------------ ANIMALES
# head = (w, h, d) de la cabeza (igual que ReptileShapes.java)
ANIMALS = {
    # serpientes
    "titanoboa":      dict(head=(10, 7, 14), base=(78, 68, 38), alt=(40, 32, 16), pat="diamond", eye=(240, 200, 50)),
    "anaconda":       dict(head=(6, 4, 8),   base=(62, 90, 42), alt=(26, 42, 20), pat="spots",   eye=(225, 185, 40)),
    "king_cobra":     dict(head=(4, 3, 6),   base=(124, 108, 62), alt=(62, 50, 28), pat="bands", eye=(205, 160, 30)),
    "rattlesnake":    dict(head=(4, 3, 6),   base=(182, 152, 102), alt=(104, 72, 40), pat="diamond", eye=(215, 170, 40)),
    "black_mamba":    dict(head=(3, 3, 6),   base=(76, 74, 68), alt=(52, 50, 46), pat="plain",  eye=(205, 205, 60)),
    # cuatro patas
    "nile_crocodile": dict(head=(6, 4, 12),  base=(86, 102, 62), alt=(46, 58, 34), pat="blotch", eye=(235, 205, 60)),
    "caiman":         dict(head=(4, 3, 8),   base=(52, 94, 50), alt=(158, 154, 62), pat="bands", eye=(235, 185, 40)),
    "alligator":      dict(head=(6, 4, 11),  base=(42, 54, 46), alt=(92, 102, 88), pat="blotch", eye=(225, 175, 40)),
    "iguana":         dict(head=(4, 4, 6),   base=(90, 170, 62), alt=(48, 108, 40), pat="bands", eye=(235, 150, 30)),
    "gecko":          dict(head=(3, 2, 4),   base=(152, 178, 100), alt=(216, 152, 72), pat="spots", eye=(255, 225, 60)),
}
# colores del spawn egg (principal, manchas)
EGG = {
    "titanoboa": ((78, 68, 38), (200, 170, 60)),
    "anaconda": ((62, 90, 42), (20, 36, 16)),
    "king_cobra": ((124, 108, 62), (40, 32, 16)),
    "rattlesnake": ((182, 152, 102), (96, 64, 34)),
    "black_mamba": ((76, 74, 68), (170, 170, 60)),
    "nile_crocodile": ((86, 102, 62), (40, 52, 30)),
    "caiman": ((52, 94, 50), (200, 190, 70)),
    "alligator": ((42, 54, 46), (110, 120, 104)),
    "iguana": ((90, 170, 62), (230, 150, 40)),
    "gecko": ((152, 178, 100), (216, 152, 72)),
}


def pattern_color(kind, x, y, base, alt):
    if kind == "diamond":
        d = abs((x % 10) - 5) + abs((y % 10) - 5)
        return alt if d < 3 else (shade(base, 12) if d == 3 else base)
    if kind == "spots":
        h = (x * 73856093 ^ y * 19349663) & 0xFF
        return alt if h < 22 else base
    if kind == "bands":
        return alt if ((x + y // 2) // 3) % 3 == 0 else base
    if kind == "blotch":
        v = math.sin(x * 0.55) + math.cos(y * 0.75) + math.sin((x + y) * 0.3)
        return alt if v > 1.15 else base
    return base


def draw_eyes(px, head, eye):
    w, h, d = head
    ey = d + max(0, h // 2 - 1)
    dark = (10, 10, 10)
    # cara derecha (u 0..d), borde delantero en u=d-1
    px[max(0, d - 2), ey] = eye
    px[d - 1, ey] = dark
    # cara izquierda (u d+w..2d+w), borde delantero en u=d+w
    px[d + w + 1, ey] = eye
    px[d + w, ey] = dark
    # cara superior (u d..d+w, v 0..d), borde delantero en v=d-1
    px[d, max(0, d - 2)] = eye
    px[d + w - 1, max(0, d - 2)] = eye


def make_entity_texture(name, spec):
    img = Image.new("RGBA", (128, 64))
    px = img.load()
    for y in range(64):
        for x in range(128):
            c = pattern_color(spec["pat"], x, y, spec["base"], spec["alt"])
            n = random.randint(-9, 9)
            px[x, y] = shade(c, n) + (255,)
    draw_eyes(px, spec["head"], spec["eye"])
    out = os.path.join(A, "textures/entity", name + ".png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out)


def make_spawn_egg(name, c1, c2):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y in range(16):
        for x in range(16):
            dx, dy = (x - 7.5) / 5.2, (y - 8.2) / 6.8
            r = dx * dx + dy * dy
            if r <= 1.0:
                col = c1
                if r > 0.72:
                    col = shade(c1, -38)
                px[x, y] = col + (255,)
    rng = random.Random(name)
    placed = 0
    while placed < 9:
        x, y = rng.randint(3, 12), rng.randint(3, 13)
        dx, dy = (x - 7.5) / 5.2, (y - 8.2) / 6.8
        if dx * dx + dy * dy < 0.6:
            px[x, y] = c2 + (255,)
            if rng.random() < 0.5 and x + 1 < 13:
                px[x + 1, y] = c2 + (255,)
            placed += 1
    px[5, 4] = shade(c1, 55) + (255,)
    px[6, 4] = shade(c1, 40) + (255,)
    out = os.path.join(A, "textures/item", name + "_spawn_egg.png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out)


# ------------------------------------------------------------------ ITEMS 16x16
def save_item(name, img):
    out = os.path.join(A, "textures/item", name + ".png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out)


def make_scale(name, base, alt):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    # escama en forma de hoja/gota
    for y in range(16):
        for x in range(16):
            dx, dy = (x - 7.5) / 5.0, (y - 7.5) / 6.5
            if abs(dx) + abs(dy) * 0.8 <= 1.0 and dx * dx + dy * dy <= 1.05:
                edge = abs(dx) + abs(dy) * 0.8 > 0.8
                px[x, y] = (shade(base, -45) if edge else base) + (255,)
    for i in range(4, 12):
        px[7, i] = alt + (255,)
        px[8, i] = shade(alt, -12) + (255,)
    for (x, y) in ((5, 7), (10, 7), (6, 10), (9, 10)):
        px[x, y] = alt + (255,)
    px[6, 5] = shade(base, 60) + (255,)
    save_item(name, img)


def make_blob(name, base, hi, outline):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y in range(16):
        for x in range(16):
            dx, dy = (x - 7.5) / 5.5, (y - 8.5) / 5.0
            r = dx * dx + dy * dy
            if r <= 1.0:
                px[x, y] = (outline if r > 0.7 else base) + (255,)
    for (x, y) in ((5, 6), (6, 5), (6, 6), (9, 10)):
        px[x, y] = hi + (255,)
    save_item(name, img)


def make_meat(name, base, hi, outline, bone=(235, 230, 215)):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y in range(16):
        for x in range(16):
            dx, dy = (x - 7.0) / 5.0, (y - 7.0) / 4.0
            r = dx * dx + dy * dy
            if r <= 1.0:
                px[x, y] = (outline if r > 0.68 else base) + (255,)
    for (x, y) in ((5, 5), (6, 5), (6, 6), (9, 8), (10, 8)):
        px[x, y] = hi + (255,)
    # hueso
    for i in range(11, 15):
        px[i, i - 4] = bone + (255,)
    px[14, 9] = bone + (255,)
    px[15, 10] = bone + (255,)
    px[14, 11] = bone + (255,)
    save_item(name, img)


def make_armor_icon(name, kind, base, alt):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    dark = shade(base, -55)
    shapes = {
        "helmet": [(3, 5, 12, 11), (3, 11, 5, 12), (10, 11, 12, 12)],
        "chestplate": [(4, 2, 11, 14), (1, 2, 4, 8), (11, 2, 14, 8)],
        "leggings": [(3, 2, 12, 6), (3, 6, 7, 14), (8, 6, 12, 14)],
        "boots": [(2, 6, 6, 13), (9, 6, 13, 13)],
    }
    for (x0, y0, x1, y1) in shapes[kind]:
        d.rectangle((x0, y0, x1, y1), fill=base + (255,), outline=dark + (255,))
    if kind == "helmet":
        d.rectangle((5, 8, 10, 10), fill=(0, 0, 0, 0))
    if kind == "chestplate":
        d.rectangle((6, 2, 9, 3), fill=(0, 0, 0, 0))
    px = img.load()
    for y in range(16):
        for x in range(16):
            if px[x, y][3] and ((x + y) % 4 == 0):
                px[x, y] = alt + (255,)
    save_item(name, img)


MATERIALS = {
    "snake_scale": dict(base=(92, 124, 60), alt=(60, 88, 40), scale_item="snake_scale"),
    "crocodile_scale": dict(base=(60, 78, 56), alt=(36, 48, 36), scale_item="crocodile_scale"),
    "titanoboa_scale": dict(base=(120, 104, 44), alt=(78, 62, 24), scale_item="titanoboa_scale"),
}
PIECES = ["helmet", "chestplate", "leggings", "boots"]


def make_armor_layer(mat, spec, leggings):
    img = Image.new("RGBA", (64, 32))
    px = img.load()
    base = shade(spec["base"], -14) if leggings else spec["base"]
    for y in range(32):
        for x in range(64):
            d = abs((x % 6) - 3) + abs((y % 6) - 3)
            c = spec["alt"] if d < 2 else (shade(base, 10) if d == 2 else base)
            px[x, y] = shade(c, random.randint(-6, 6)) + (255,)
    sub = "humanoid_leggings" if leggings else "humanoid"
    out = os.path.join(A, "textures/entity/equipment", sub, mat + ".png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out)


# ------------------------------------------------------------------ BLOQUES 16x16
def save_block(name, img):
    out = os.path.join(A, "textures/block", name + ".png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out)


def tex_planks(base=(176, 98, 62)):
    img = Image.new("RGBA", (16, 16), base + (255,))
    px = img.load()
    for y in range(16):
        for x in range(16):
            c = base
            if y % 4 == 3:
                c = shade(base, -42)
            elif (x + (y // 4) * 5) % 8 == 0:
                c = shade(base, -22)
            else:
                c = shade(base, random.randint(-9, 9))
            px[x, y] = c + (255,)
    return img


def tex_log_side(base=(98, 60, 38)):
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for x in range(16):
        col = shade(base, -26 if x % 5 in (0, 1) else random.randint(-8, 8))
        for y in range(16):
            px[x, y] = shade(col, random.randint(-8, 8)) + (255,)
    return img


def tex_log_top(rings=(176, 98, 62), bark=(98, 60, 38)):
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for y in range(16):
        for x in range(16):
            d = max(abs(x - 7.5), abs(y - 7.5))
            if d > 6.2:
                c = bark
            else:
                c = shade(rings, -30 if int(d) % 2 == 1 else 0)
            px[x, y] = shade(c, random.randint(-5, 5)) + (255,)
    return img


def tex_leaves():
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for y in range(16):
        for x in range(16):
            r = random.random()
            if r < 0.14:
                px[x, y] = (0, 0, 0, 0)
            else:
                base = (40, 130, 48) if r < 0.6 else (30, 106, 38) if r < 0.85 else (62, 158, 60)
                px[x, y] = base + (255,)
    return img


def tex_sapling():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y in range(8, 16):
        px[7, y] = (98, 60, 38, 255)
        px[8, y] = (78, 46, 28, 255)
    for (cx, cy, r) in ((8, 5, 4), (5, 8, 2), (11, 8, 2)):
        for y in range(16):
            for x in range(16):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    px[x, y] = ((40, 130, 48) if (x + y) % 3 else (62, 158, 60)) + (255,)
    return img


def tex_door(top):
    base = (176, 98, 62)
    img = tex_planks(base)
    px = img.load()
    for i in range(16):
        for (x, y) in ((0, i), (15, i), (i, 0 if top else 15)):
            px[x, y] = shade(base, -50) + (255,)
    for y in range(3, 7 if top else 13):
        for x in range(3, 13):
            if x in (3, 12) or y in (3, (6 if top else 12)):
                px[x, y] = shade(base, -36) + (255,)
    if not top:
        px[12, 8] = (230, 200, 90, 255)
        px[12, 9] = (200, 170, 70, 255)
    return img


def tex_trapdoor():
    base = (176, 98, 62)
    img = tex_planks(base)
    px = img.load()
    for i in range(16):
        for (x, y) in ((0, i), (15, i), (i, 0), (i, 15), (i, 7), (i, 8)):
            px[x, y] = shade(base, -50) + (255,)
    return img


def tex_door_item():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle((4, 0, 11, 15), fill=(176, 98, 62, 255), outline=(110, 58, 34, 255))
    d.rectangle((6, 2, 9, 5), outline=(130, 70, 42, 255))
    d.rectangle((6, 9, 9, 13), outline=(130, 70, 42, 255))
    img.putpixel((9, 8), (230, 200, 90, 255))
    return img


def write_blocks_textures():
    planks = tex_planks()
    log_side = tex_log_side()
    s_log_side = tex_log_side((176, 98, 62))
    save_block("ceiba_planks", planks)
    save_block("ceiba_log", log_side)
    save_block("ceiba_log_top", tex_log_top())
    save_block("stripped_ceiba_log", s_log_side)
    save_block("stripped_ceiba_log_top", tex_log_top(bark=(176, 98, 62)))
    save_block("ceiba_leaves", tex_leaves())
    save_block("ceiba_sapling", tex_sapling())
    save_block("ceiba_door_top", tex_door(True))
    save_block("ceiba_door_bottom", tex_door(False))
    save_block("ceiba_trapdoor", tex_trapdoor())
    save_item("ceiba_door", tex_door_item())


# ------------------------------------------------------------------ MODELOS / BLOCKSTATES
def item_def(name, model):
    wjson(f"{A}/items/{name}.json", {"model": {"type": "minecraft:model", "model": model}})


def item_generated(name, tex=None):
    wjson(f"{A}/models/item/{name}.json", {
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"{NS}:item/{tex or name}"}})
    item_def(name, f"{NS}:item/{name}")


def bmodel(name, parent, textures):
    wjson(f"{A}/models/block/{name}.json", {"parent": parent, "textures": textures})


def bstate(name, obj):
    wjson(f"{A}/blockstates/{name}.json", obj)


def write_block_assets():
    P = f"{NS}:block/ceiba_planks"
    # troncos y maderas
    for (name, side, end) in (
            ("ceiba_log", "ceiba_log", "ceiba_log_top"),
            ("stripped_ceiba_log", "stripped_ceiba_log", "stripped_ceiba_log_top"),
            ("ceiba_wood", "ceiba_log", "ceiba_log"),
            ("stripped_ceiba_wood", "stripped_ceiba_log", "stripped_ceiba_log")):
        tex = {"end": f"{NS}:block/{end}", "side": f"{NS}:block/{side}"}
        bmodel(name, "minecraft:block/cube_column", tex)
        bmodel(name + "_horizontal", "minecraft:block/cube_column_horizontal", tex)
        bstate(name, {"variants": {
            "axis=y": {"model": f"{NS}:block/{name}"},
            "axis=z": {"model": f"{NS}:block/{name}_horizontal", "x": 90},
            "axis=x": {"model": f"{NS}:block/{name}_horizontal", "x": 90, "y": 90}}})
        item_def(name, f"{NS}:block/{name}")

    # tablones
    bmodel("ceiba_planks", "minecraft:block/cube_all", {"all": P})
    bstate("ceiba_planks", {"variants": {"": {"model": f"{NS}:block/ceiba_planks"}}})
    item_def("ceiba_planks", f"{NS}:block/ceiba_planks")

    # escaleras
    st = {"bottom": P, "top": P, "side": P}
    bmodel("ceiba_stairs", "minecraft:block/stairs", st)
    bmodel("ceiba_stairs_inner", "minecraft:block/inner_stairs", st)
    bmodel("ceiba_stairs_outer", "minecraft:block/outer_stairs", st)
    base_y = {"east": 0, "south": 90, "west": 180, "north": 270}
    variants = {}
    for facing, by in base_y.items():
        for half in ("bottom", "top"):
            for shape in ("straight", "inner_left", "inner_right", "outer_left", "outer_right"):
                model = "ceiba_stairs" if shape == "straight" else \
                    ("ceiba_stairs_inner" if shape.startswith("inner") else "ceiba_stairs_outer")
                y = by
                if shape != "straight":
                    left = shape.endswith("left")
                    if half == "bottom":
                        y = by - 90 if left else by
                    else:
                        y = by if left else by + 90
                y %= 360
                v = {"model": f"{NS}:block/{model}", "uvlock": True}
                if half == "top":
                    v["x"] = 180
                if y:
                    v["y"] = y
                variants[f"facing={facing},half={half},shape={shape}"] = v
    bstate("ceiba_stairs", {"variants": variants})
    item_def("ceiba_stairs", f"{NS}:block/ceiba_stairs")

    # losas
    bmodel("ceiba_slab", "minecraft:block/slab", st)
    bmodel("ceiba_slab_top", "minecraft:block/slab_top", st)
    bstate("ceiba_slab", {"variants": {
        "type=bottom": {"model": f"{NS}:block/ceiba_slab"},
        "type=top": {"model": f"{NS}:block/ceiba_slab_top"},
        "type=double": {"model": f"{NS}:block/ceiba_planks"}}})
    item_def("ceiba_slab", f"{NS}:block/ceiba_slab")

    # valla
    t = {"texture": P}
    bmodel("ceiba_fence_post", "minecraft:block/fence_post", t)
    bmodel("ceiba_fence_side", "minecraft:block/fence_side", t)
    bmodel("ceiba_fence_inventory", "minecraft:block/fence_inventory", t)
    mp = [{"apply": {"model": f"{NS}:block/ceiba_fence_post"}}]
    for key, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270)):
        ap = {"model": f"{NS}:block/ceiba_fence_side", "uvlock": True}
        if y:
            ap["y"] = y
        mp.append({"when": {key: "true"}, "apply": ap})
    bstate("ceiba_fence", {"multipart": mp})
    item_def("ceiba_fence", f"{NS}:block/ceiba_fence_inventory")

    # puerta de valla
    for suffix, parent in (("", "template_fence_gate"), ("_open", "template_fence_gate_open"),
                           ("_wall", "template_fence_gate_wall"), ("_wall_open", "template_fence_gate_wall_open")):
        bmodel("ceiba_fence_gate" + suffix, f"minecraft:block/{parent}", t)
    variants = {}
    for facing, y in (("south", 0), ("west", 90), ("north", 180), ("east", 270)):
        for in_wall in ("false", "true"):
            for opened in ("false", "true"):
                model = "ceiba_fence_gate" + ("_wall" if in_wall == "true" else "") + ("_open" if opened == "true" else "")
                v = {"model": f"{NS}:block/{model}", "uvlock": True}
                if y:
                    v["y"] = y
                variants[f"facing={facing},in_wall={in_wall},open={opened}"] = v
    bstate("ceiba_fence_gate", {"variants": variants})
    item_def("ceiba_fence_gate", f"{NS}:block/ceiba_fence_gate")

    # puerta
    dt = {"top": f"{NS}:block/ceiba_door_top", "bottom": f"{NS}:block/ceiba_door_bottom"}
    for half in ("bottom", "top"):
        for hinge in ("left", "right"):
            bmodel(f"ceiba_door_{half}_{hinge}", f"minecraft:block/door_{half}_{hinge}", dt)
            bmodel(f"ceiba_door_{half}_{hinge}_open", f"minecraft:block/door_{half}_{hinge}_open", dt)
    variants = {}
    for facing, y0 in (("east", 0), ("south", 90), ("west", 180), ("north", 270)):
        for half, hn in (("lower", "bottom"), ("upper", "top")):
            for hinge in ("left", "right"):
                for opened in ("false", "true"):
                    model = f"ceiba_door_{hn}_{hinge}" + ("_open" if opened == "true" else "")
                    y = y0
                    if opened == "true":
                        y += 90 if hinge == "left" else 270
                    y %= 360
                    v = {"model": f"{NS}:block/{model}"}
                    if y:
                        v["y"] = y
                    variants[f"facing={facing},half={half},hinge={hinge},open={opened}"] = v
    bstate("ceiba_door", {"variants": variants})
    item_generated("ceiba_door")

    # trampilla
    tt = {"texture": f"{NS}:block/ceiba_trapdoor"}
    bmodel("ceiba_trapdoor_bottom", "minecraft:block/template_orientable_trapdoor_bottom", tt)
    bmodel("ceiba_trapdoor_top", "minecraft:block/template_orientable_trapdoor_top", tt)
    bmodel("ceiba_trapdoor_open", "minecraft:block/template_orientable_trapdoor_open", tt)
    variants = {}
    for facing, yb, yt in (("north", 0, 180), ("south", 180, 0), ("east", 90, 270), ("west", 270, 90)):
        for half in ("bottom", "top"):
            variants[f"facing={facing},half={half},open=false"] = {
                "model": f"{NS}:block/ceiba_trapdoor_{half}"}
            v = {"model": f"{NS}:block/ceiba_trapdoor_open"}
            if half == "top":
                v["x"] = 180
                if yt:
                    v["y"] = yt
            elif yb:
                v["y"] = yb
            variants[f"facing={facing},half={half},open=true"] = v
    bstate("ceiba_trapdoor", {"variants": variants})
    item_def("ceiba_trapdoor", f"{NS}:block/ceiba_trapdoor_bottom")

    # botón
    bmodel("ceiba_button", "minecraft:block/button", t)
    bmodel("ceiba_button_pressed", "minecraft:block/button_pressed", t)
    bmodel("ceiba_button_inventory", "minecraft:block/button_inventory", t)
    variants = {}
    face_rot = {"floor": (0, {"north": 0, "east": 90, "south": 180, "west": 270}),
                "wall": (90, {"north": 0, "east": 90, "south": 180, "west": 270}),
                "ceiling": (180, {"north": 180, "east": 270, "south": 0, "west": 90})}
    for face, (x, ys) in face_rot.items():
        for facing, y in ys.items():
            for powered in ("false", "true"):
                model = "ceiba_button" + ("_pressed" if powered == "true" else "")
                v = {"model": f"{NS}:block/{model}"}
                if face != "floor":
                    v["uvlock"] = True
                if x:
                    v["x"] = x
                if y:
                    v["y"] = y
                variants[f"face={face},facing={facing},powered={powered}"] = v
    bstate("ceiba_button", {"variants": variants})
    item_def("ceiba_button", f"{NS}:block/ceiba_button_inventory")

    # placa de presión
    bmodel("ceiba_pressure_plate_up", "minecraft:block/pressure_plate_up", t)
    bmodel("ceiba_pressure_plate_down", "minecraft:block/pressure_plate_down", t)
    bstate("ceiba_pressure_plate", {"variants": {
        "powered=false": {"model": f"{NS}:block/ceiba_pressure_plate_up"},
        "powered=true": {"model": f"{NS}:block/ceiba_pressure_plate_down"}}})
    item_def("ceiba_pressure_plate", f"{NS}:block/ceiba_pressure_plate_up")

    # hojas y sapling
    bmodel("ceiba_leaves", "minecraft:block/leaves", {"all": f"{NS}:block/ceiba_leaves"})
    bstate("ceiba_leaves", {"variants": {"": {"model": f"{NS}:block/ceiba_leaves"}}})
    item_def("ceiba_leaves", f"{NS}:block/ceiba_leaves")
    bmodel("ceiba_sapling", "minecraft:block/cross", {"cross": f"{NS}:block/ceiba_sapling"})
    bstate("ceiba_sapling", {"variants": {"": {"model": f"{NS}:block/ceiba_sapling"}}})
    wjson(f"{A}/models/item/ceiba_sapling.json", {
        "parent": "minecraft:item/generated", "textures": {"layer0": f"{NS}:block/ceiba_sapling"}})
    item_def("ceiba_sapling", f"{NS}:item/ceiba_sapling")


# ------------------------------------------------------------------ NOMBRES
WOOD = ["ceiba_log", "stripped_ceiba_log", "ceiba_wood", "stripped_ceiba_wood", "ceiba_planks",
        "ceiba_stairs", "ceiba_slab", "ceiba_fence", "ceiba_fence_gate", "ceiba_door",
        "ceiba_trapdoor", "ceiba_button", "ceiba_pressure_plate", "ceiba_leaves", "ceiba_sapling"]

ES = {
    "titanoboa": "Titanoboa", "anaconda": "Anaconda verde", "king_cobra": "Cobra real",
    "rattlesnake": "Serpiente de cascabel", "black_mamba": "Mamba negra",
    "nile_crocodile": "Cocodrilo del Nilo", "caiman": "Caimán", "alligator": "Aligátor",
    "iguana": "Iguana", "gecko": "Gecko",
}
EN = {
    "titanoboa": "Titanoboa", "anaconda": "Green Anaconda", "king_cobra": "King Cobra",
    "rattlesnake": "Rattlesnake", "black_mamba": "Black Mamba",
    "nile_crocodile": "Nile Crocodile", "caiman": "Caiman", "alligator": "Alligator",
    "iguana": "Iguana", "gecko": "Gecko",
}
ITEMS_ES = {
    "snake_scale": "Escama de serpiente", "crocodile_scale": "Escama de cocodrilo",
    "titanoboa_scale": "Escama de titanoboa", "gecko_slime": "Baba pegajosa de gecko",
    "snake_meat": "Carne de serpiente", "cooked_snake_meat": "Carne de serpiente cocinada",
    "crocodile_meat": "Carne de cocodrilo", "cooked_crocodile_meat": "Carne de cocodrilo cocinada",
    "iguana_meat": "Carne de iguana", "cooked_iguana_meat": "Carne de iguana cocinada",
    "gecko_meat": "Carne de gecko", "cooked_gecko_meat": "Carne de gecko cocinada",
}
ITEMS_EN = {
    "snake_scale": "Snake Scale", "crocodile_scale": "Crocodile Scale",
    "titanoboa_scale": "Titanoboa Scale", "gecko_slime": "Sticky Gecko Slime",
    "snake_meat": "Snake Meat", "cooked_snake_meat": "Cooked Snake Meat",
    "crocodile_meat": "Crocodile Meat", "cooked_crocodile_meat": "Cooked Crocodile Meat",
    "iguana_meat": "Iguana Meat", "cooked_iguana_meat": "Cooked Iguana Meat",
    "gecko_meat": "Gecko Meat", "cooked_gecko_meat": "Cooked Gecko Meat",
}
PIECE_ES = {"helmet": "Casco", "chestplate": "Peto", "leggings": "Pantalones", "boots": "Botas"}
PIECE_EN = {"helmet": "Helmet", "chestplate": "Chestplate", "leggings": "Leggings", "boots": "Boots"}
MAT_ES = {"snake_scale": "de escamas de serpiente", "crocodile_scale": "de escamas de cocodrilo",
          "titanoboa_scale": "de escamas de titanoboa"}
MAT_EN = {"snake_scale": "Snake Scale", "crocodile_scale": "Crocodile Scale",
          "titanoboa_scale": "Titanoboa Scale"}
WOOD_ES = {
    "ceiba_log": "Tronco de ceiba", "stripped_ceiba_log": "Tronco de ceiba sin corteza",
    "ceiba_wood": "Madera de ceiba", "stripped_ceiba_wood": "Madera de ceiba sin corteza",
    "ceiba_planks": "Tablones de ceiba", "ceiba_stairs": "Escaleras de ceiba",
    "ceiba_slab": "Losa de ceiba", "ceiba_fence": "Valla de ceiba",
    "ceiba_fence_gate": "Puerta de valla de ceiba", "ceiba_door": "Puerta de ceiba",
    "ceiba_trapdoor": "Trampilla de ceiba", "ceiba_button": "Botón de ceiba",
    "ceiba_pressure_plate": "Placa de presión de ceiba", "ceiba_leaves": "Hojas de ceiba",
    "ceiba_sapling": "Brote de ceiba"}
WOOD_EN = {
    "ceiba_log": "Ceiba Log", "stripped_ceiba_log": "Stripped Ceiba Log",
    "ceiba_wood": "Ceiba Wood", "stripped_ceiba_wood": "Stripped Ceiba Wood",
    "ceiba_planks": "Ceiba Planks", "ceiba_stairs": "Ceiba Stairs",
    "ceiba_slab": "Ceiba Slab", "ceiba_fence": "Ceiba Fence",
    "ceiba_fence_gate": "Ceiba Fence Gate", "ceiba_door": "Ceiba Door",
    "ceiba_trapdoor": "Ceiba Trapdoor", "ceiba_button": "Ceiba Button",
    "ceiba_pressure_plate": "Ceiba Pressure Plate", "ceiba_leaves": "Ceiba Leaves",
    "ceiba_sapling": "Ceiba Sapling"}


def write_lang():
    for code, ent, items, piece, mat, wood, tab, biome in (
            ("es_es", ES, ITEMS_ES, PIECE_ES, MAT_ES, WOOD_ES, "Reptiles", "Ciénaga Reptil"),
            ("en_us", EN, ITEMS_EN, PIECE_EN, MAT_EN, WOOD_EN, "Reptiles", "Reptile Swamp")):
        lang = {"itemGroup.reptilia.reptiles": tab, "biome.reptilia.reptile_swamp": biome}
        for k, v in ent.items():
            lang[f"entity.{NS}.{k}"] = v
            lang[f"item.{NS}.{k}_spawn_egg"] = (f"Spawn egg de {v}" if code == "es_es" else f"{v} Spawn Egg")
        for k, v in items.items():
            lang[f"item.{NS}.{k}"] = v
        for m, mname in mat.items():
            for p, pname in piece.items():
                lang[f"item.{NS}.{m}_{p}"] = (f"{pname} {mname}" if code == "es_es" else f"{mname} {pname}")
        for k, v in wood.items():
            lang[f"block.{NS}.{k}"] = v
        wjson(f"{A}/lang/{code}.json", lang)


# ------------------------------------------------------------------ DATA
def loot_item(name, lo, hi):
    entry = {"type": "minecraft:item", "name": f"{NS}:{name}"}
    if lo != hi or lo != 1:
        entry["functions"] = [{"function": "minecraft:set_count",
                               "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]
    return {"rolls": 1, "entries": [entry]}


def write_entity_loot():
    table = {
        "titanoboa": [("titanoboa_scale", 3, 5), ("snake_scale", 2, 4), ("snake_meat", 2, 4)],
        "anaconda": [("snake_scale", 1, 3), ("snake_meat", 1, 3)],
        "king_cobra": [("snake_scale", 1, 2), ("snake_meat", 1, 2)],
        "rattlesnake": [("snake_scale", 1, 2), ("snake_meat", 0, 2)],
        "black_mamba": [("snake_scale", 1, 2), ("snake_meat", 0, 2)],
        "nile_crocodile": [("crocodile_scale", 1, 3), ("crocodile_meat", 1, 3)],
        "caiman": [("crocodile_scale", 1, 2), ("crocodile_meat", 1, 2)],
        "alligator": [("crocodile_scale", 1, 3), ("crocodile_meat", 1, 3)],
        "iguana": [("iguana_meat", 1, 2)],
        "gecko": [("gecko_meat", 0, 1), ("gecko_slime", 1, 2)],
    }
    for ent, drops in table.items():
        wjson(f"{D}/loot_table/entities/{ent}.json", {
            "type": "minecraft:entity",
            "pools": [loot_item(n, lo, hi) for (n, lo, hi) in drops]})


def block_loot(name, extra_pools=None, functions=None, conditions=None):
    entry = {"type": "minecraft:item", "name": f"{NS}:{name}"}
    if functions:
        entry["functions"] = functions
    pool = {"rolls": 1, "bonus_rolls": 0, "entries": [entry],
            "conditions": conditions or [{"condition": "minecraft:survives_explosion"}]}
    wjson(f"{D}/loot_table/blocks/{name}.json", {"type": "minecraft:block", "pools": [pool]})


def write_block_loot():
    for name in WOOD:
        if name == "ceiba_slab":
            block_loot(name, functions=[{
                "function": "minecraft:set_count", "count": 2, "add": False,
                "conditions": [{"condition": "minecraft:block_state_property",
                                "block": f"{NS}:ceiba_slab", "properties": {"type": "double"}}]}])
        elif name == "ceiba_door":
            block_loot(name, conditions=[
                {"condition": "minecraft:survives_explosion"},
                {"condition": "minecraft:block_state_property", "block": f"{NS}:ceiba_door",
                 "properties": {"half": "lower"}}])
        elif name == "ceiba_leaves":
            wjson(f"{D}/loot_table/blocks/ceiba_leaves.json", {
                "type": "minecraft:block",
                "pools": [
                    {"rolls": 1, "bonus_rolls": 0,
                     "entries": [{"type": "minecraft:item", "name": f"{NS}:ceiba_sapling"}],
                     "conditions": [{"condition": "minecraft:random_chance", "chance": 0.06}]},
                    {"rolls": 1, "bonus_rolls": 0,
                     "entries": [{"type": "minecraft:item", "name": "minecraft:stick",
                                  "functions": [{"function": "minecraft:set_count",
                                                 "count": {"type": "minecraft:uniform", "min": 1, "max": 2}}]}],
                     "conditions": [{"condition": "minecraft:random_chance", "chance": 0.1}]}]})
        else:
            block_loot(name)


def shaped(name, pattern, key, result, count=1, category="misc"):
    wjson(f"{D}/recipe/{name}.json", {
        "type": "minecraft:crafting_shaped", "category": category,
        "pattern": pattern, "key": key, "result": {"id": f"{NS}:{result}", "count": count}})


def shapeless(name, ingredients, result, count=1, category="misc"):
    wjson(f"{D}/recipe/{name}.json", {
        "type": "minecraft:crafting_shapeless", "category": category,
        "ingredients": ingredients, "result": {"id": f"{NS}:{result}", "count": count}})


def cooking(raw, cooked):
    for kind, time, folder in (("smelting", 200, "smelting"), ("smoking", 100, "smoking"),
                               ("campfire_cooking", 600, "campfire")):
        wjson(f"{D}/recipe/{cooked}_from_{folder}.json", {
            "type": f"minecraft:{kind}", "category": "food",
            "ingredient": f"{NS}:{raw}", "result": {"id": f"{NS}:{cooked}"},
            "experience": 0.35, "cookingtime": time})


def write_recipes():
    # armaduras
    for mat in MATERIALS:
        s = f"{NS}:{mat}"
        k = {"#": s}
        shaped(f"{mat}_helmet", ["###", "# #"], k, f"{mat}_helmet", category="equipment")
        shaped(f"{mat}_chestplate", ["# #", "###", "###"], k, f"{mat}_chestplate", category="equipment")
        shaped(f"{mat}_leggings", ["###", "# #", "# #"], k, f"{mat}_leggings", category="equipment")
        shaped(f"{mat}_boots", ["# #", "# #"], k, f"{mat}_boots", category="equipment")
    # baba de gecko -> bloque de slime (variante de las 9 bolas de slime)
    wjson(f"{D}/recipe/slime_block_from_gecko_slime.json", {
        "type": "minecraft:crafting_shaped", "category": "redstone",
        "pattern": ["###", "###", "###"], "key": {"#": f"{NS}:gecko_slime"},
        "result": {"id": "minecraft:slime_block", "count": 1}})
    # carnes
    cooking("snake_meat", "cooked_snake_meat")
    cooking("crocodile_meat", "cooked_crocodile_meat")
    cooking("iguana_meat", "cooked_iguana_meat")
    cooking("gecko_meat", "cooked_gecko_meat")
    # madera de ceiba
    P = f"{NS}:ceiba_planks"
    shapeless("ceiba_planks", [f"#{NS}:ceiba_logs"], "ceiba_planks", 4, "building")
    shaped("ceiba_wood", ["##", "##"], {"#": f"{NS}:ceiba_log"}, "ceiba_wood", 3, "building")
    shaped("stripped_ceiba_wood", ["##", "##"], {"#": f"{NS}:stripped_ceiba_log"}, "stripped_ceiba_wood", 3, "building")
    shaped("ceiba_stairs", ["#  ", "## ", "###"], {"#": P}, "ceiba_stairs", 4, "building")
    shaped("ceiba_slab", ["###"], {"#": P}, "ceiba_slab", 6, "building")
    shaped("ceiba_fence", ["#S#", "#S#"], {"#": P, "S": "minecraft:stick"}, "ceiba_fence", 3, "redstone")
    shaped("ceiba_fence_gate", ["S#S", "S#S"], {"#": P, "S": "minecraft:stick"}, "ceiba_fence_gate", 1, "redstone")
    shaped("ceiba_door", ["##", "##", "##"], {"#": P}, "ceiba_door", 3, "redstone")
    shaped("ceiba_trapdoor", ["###", "###"], {"#": P}, "ceiba_trapdoor", 2, "redstone")
    shapeless("ceiba_button", [P], "ceiba_button", 1, "redstone")
    shaped("ceiba_pressure_plate", ["##"], {"#": P}, "ceiba_pressure_plate", 1, "redstone")


def tag(path, values, replace=False):
    wjson(path, {"replace": replace, "values": values})


def write_tags():
    blocks = [f"{NS}:{n}" for n in WOOD]
    logs = [f"{NS}:{n}" for n in ("ceiba_log", "stripped_ceiba_log", "ceiba_wood", "stripped_ceiba_wood")]
    groups = {
        "logs": logs, "logs_that_burn": logs, "planks": [f"{NS}:ceiba_planks"],
        "wooden_stairs": [f"{NS}:ceiba_stairs"], "wooden_slabs": [f"{NS}:ceiba_slab"],
        "wooden_fences": [f"{NS}:ceiba_fence"], "fence_gates": [f"{NS}:ceiba_fence_gate"],
        "wooden_doors": [f"{NS}:ceiba_door"], "wooden_trapdoors": [f"{NS}:ceiba_trapdoor"],
        "wooden_buttons": [f"{NS}:ceiba_button"], "wooden_pressure_plates": [f"{NS}:ceiba_pressure_plate"],
        "leaves": [f"{NS}:ceiba_leaves"], "saplings": [f"{NS}:ceiba_sapling"],
    }
    for g, vals in groups.items():
        tag(f"{M}/tags/block/{g}.json", vals)
        tag(f"{M}/tags/item/{g}.json", vals)
    tag(f"{M}/tags/block/mineable/axe.json", [b for b in blocks if "leaves" not in b and "sapling" not in b])
    tag(f"{M}/tags/block/mineable/hoe.json", [f"{NS}:ceiba_leaves"])
    tag(f"{M}/tags/block/replaceable_by_trees.json", [f"{NS}:ceiba_leaves"])
    tag(f"{D}/tags/item/ceiba_logs.json", logs)
    tag(f"{D}/tags/item/repairs_snake_scale_armor.json", [f"{NS}:snake_scale"])
    tag(f"{D}/tags/item/repairs_crocodile_scale_armor.json", [f"{NS}:crocodile_scale"])
    tag(f"{D}/tags/item/repairs_titanoboa_scale_armor.json", [f"{NS}:titanoboa_scale"])


def write_worldgen():
    # Árbol de ceiba: grande, de copa ancha (estilo roble gigante)
    wjson(f"{D}/worldgen/configured_feature/ceiba_tree.json", {
        "type": "minecraft:tree",
        "config": {
            "trunk_provider": {"type": "minecraft:simple_state_provider",
                               "state": {"Name": f"{NS}:ceiba_log", "Properties": {"axis": "y"}}},
            "foliage_provider": {"type": "minecraft:simple_state_provider",
                                 "state": {"Name": f"{NS}:ceiba_leaves"}},
            "trunk_placer": {"type": "minecraft:fancy_trunk_placer",
                             "base_height": 6, "height_rand_a": 12, "height_rand_b": 0},
            "foliage_placer": {"type": "minecraft:fancy_foliage_placer",
                               "radius": 3, "offset": 4, "height": 4},
            "minimum_size": {"type": "minecraft:two_layers_feature_size",
                             "limit": 0, "lower_size": 0, "upper_size": 0},
            "dirt_provider": {"type": "minecraft:simple_state_provider",
                              "state": {"Name": "minecraft:dirt"}},
            "decorators": [],
            "ignore_vines": True}})
    wjson(f"{D}/worldgen/placed_feature/ceiba_tree.json", {
        "feature": f"{NS}:ceiba_tree",
        "placement": [
            {"type": "minecraft:count", "count": 4},
            {"type": "minecraft:in_square"},
            {"type": "minecraft:surface_water_depth_filter", "max_water_depth": 2},
            {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR"},
            {"type": "minecraft:block_predicate_filter", "predicate": {
                "type": "minecraft:would_survive", "state": {"Name": f"{NS}:ceiba_sapling"}}},
            {"type": "minecraft:biome"}]})

    def spawners():
        return {"monster": [], "creature": [], "ambient": [], "axolotls": [],
                "underground_water_creature": [], "water_creature": [], "water_ambient": [], "misc": []}

    features = [[] for _ in range(11)]
    features[4 - 1] = []
    features[6] = ["minecraft:ore_dirt", "minecraft:ore_gravel", "minecraft:ore_coal_upper",
                   "minecraft:ore_coal_lower", "minecraft:ore_iron_upper", "minecraft:ore_iron_middle",
                   "minecraft:ore_gold", "minecraft:ore_redstone", "minecraft:ore_diamond",
                   "minecraft:ore_lapis", "minecraft:ore_copper"]
    features[8] = ["minecraft:spring_water", "minecraft:spring_lava"]
    features[9] = [f"{NS}:ceiba_tree", "minecraft:patch_grass_normal", "minecraft:flower_swamp",
                   "minecraft:patch_waterlily", "minecraft:brown_mushroom_swamp",
                   "minecraft:red_mushroom_swamp", "minecraft:patch_sugar_cane_swamp",
                   "minecraft:seagrass_swamp"]
    features[10] = ["minecraft:freeze_top_layer"]

    wjson(f"{D}/worldgen/biome/reptile_swamp.json", {
        "temperature": 0.9,
        "downfall": 0.95,
        "has_precipitation": True,
        "effects": {
            "water_color": 3445342,       # verde turbio
            "foliage_color": 4235554,
            "grass_color": 6200098},
        "spawners": spawners(),
        "spawn_costs": {},
        "carvers": ["minecraft:cave", "minecraft:cave_extra_underground", "minecraft:canyon"],
        "features": features})


def main():
    import gen_entities, gen_extra
    gen_entities.generate()   # modelos (Java) + texturas de los 10 reptiles
    for name, (c1, c2) in EGG.items():
        make_spawn_egg(name, c1, c2)
        item_generated(name + "_spawn_egg")

    make_scale("snake_scale", (92, 124, 60), (150, 190, 96))
    make_scale("crocodile_scale", (66, 84, 60), (120, 140, 100))
    make_scale("titanoboa_scale", (150, 126, 50), (236, 210, 110))
    make_blob("gecko_slime", (120, 200, 90), (200, 255, 170), (64, 130, 54))
    make_meat("snake_meat", (214, 140, 130), (240, 180, 170), (150, 84, 80))
    make_meat("cooked_snake_meat", (168, 100, 60), (200, 140, 90), (104, 58, 34))
    make_meat("crocodile_meat", (200, 120, 116), (232, 164, 156), (140, 74, 70))
    make_meat("cooked_crocodile_meat", (150, 86, 50), (190, 126, 80), (92, 50, 28))
    make_meat("iguana_meat", (222, 150, 140), (244, 190, 180), (156, 92, 86))
    make_meat("cooked_iguana_meat", (176, 108, 64), (206, 146, 96), (108, 62, 36))
    make_meat("gecko_meat", (230, 164, 150), (248, 200, 190), (164, 100, 92))
    make_meat("cooked_gecko_meat", (184, 118, 72), (214, 156, 104), (112, 68, 40))
    for n in ("snake_scale", "crocodile_scale", "titanoboa_scale", "gecko_slime", "snake_meat",
              "cooked_snake_meat", "crocodile_meat", "cooked_crocodile_meat", "iguana_meat",
              "cooked_iguana_meat", "gecko_meat", "cooked_gecko_meat"):
        item_generated(n)

    for mat, spec in MATERIALS.items():
        for piece in PIECES:
            make_armor_icon(f"{mat}_{piece}", piece, spec["base"], spec["alt"])
            item_generated(f"{mat}_{piece}")
        make_armor_layer(mat, spec, False)
        make_armor_layer(mat, spec, True)
        wjson(f"{A}/equipment/{mat}.json", {"layers": {
            "humanoid": [{"texture": f"{NS}:{mat}"}],
            "humanoid_leggings": [{"texture": f"{NS}:{mat}"}]}})

    write_blocks_textures()
    write_block_assets()
    write_lang()
    write_entity_loot()
    write_block_loot()
    write_recipes()
    write_tags()
    write_worldgen()
    gen_extra.write_all()     # huevos fértiles, flora del bioma, pestaña
    import gen_polish
    gen_polish.write_all(EGG)  # texturas de ítems/armaduras pulidas (sobrescribe las básicas)
    print("Recursos generados.")


if __name__ == "__main__":
    main()
