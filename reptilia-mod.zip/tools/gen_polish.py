#!/usr/bin/env python3
"""Texturas pulidas de ítems 16x16 y capas de armadura: silueta -> contorno -> biselado -> relleno con escamas."""
import os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, "src/main/resources/assets/reptilia")


def clamp(v): return max(0, min(255, int(v)))
def shade(c, d): return (clamp(c[0] + d), clamp(c[1] + d), clamp(c[2] + d))
def mix(a, b, t): return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))


def scale_fill(base, cell=3, edge=-24, glint=18):
    def f(x, y):
        off = (cell // 2) if (y // cell) % 2 else 0
        cx, cy = (x + off) % cell, y % cell
        if cx == 0 or cy == 0:
            return shade(base, edge)
        if cx == 1 and cy == 1:
            return shade(base, glint)
        return base
    return f


def sprite(mask, fill, outline_delta=-80, outline_color=None, lit=30, dark=-26):
    """mask: imagen 'L' 16x16. fill(x,y)->rgb. Devuelve RGBA con contorno y biselado."""
    w, h = mask.size
    m = mask.load()
    def on(x, y): return 0 <= x < w and 0 <= y < h and m[x, y] > 0
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = out.load()
    edge = set()
    for y in range(h):
        for x in range(w):
            if on(x, y) and not (on(x - 1, y) and on(x + 1, y) and on(x, y - 1) and on(x, y + 1)):
                edge.add((x, y))
    for y in range(h):
        for x in range(w):
            if not on(x, y):
                continue
            c = fill(x, y)
            if (x, y) in edge:
                c = outline_color or shade(c, outline_delta)
            elif (x - 1, y) in edge or (x, y - 1) in edge:
                c = shade(c, lit)
            elif (x + 1, y) in edge or (x, y + 1) in edge:
                c = shade(c, dark)
            px[x, y] = c + (255,)
    return out


def new_mask():
    img = Image.new("L", (16, 16), 0)
    return img, ImageDraw.Draw(img)


def save(img, name):
    path = os.path.join(A, "textures/item", name + ".png")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


# ---------------------------------------------------------------- escamas
def scale_items():
    # escama de serpiente: rombo alargado con nervio central
    m, d = new_mask(); d.polygon([(8, 1), (13, 7), (8, 14), (3, 7)], fill=255)
    base = (96, 130, 62)
    img = sprite(m, scale_fill(base, 3, -14, 12), outline_delta=-85)
    px = img.load()
    for y in range(4, 12):
        if px[8, y][3]: px[8, y] = shade(base, 40) + (255,)
        if px[7, y][3]: px[7, y] = shade(base, 22) + (255,)
    save(img, "snake_scale")
    # escama de cocodrilo: placa ósea con quilla
    m, d = new_mask(); d.rounded_rectangle([3, 2, 12, 13], radius=3, fill=255)
    base = (72, 90, 64)
    img = sprite(m, scale_fill(base, 4, -20, 16), outline_delta=-80)
    px = img.load()
    for y in range(4, 12):
        if px[7, y][3] and px[7, y][:3] != (0, 0, 0): px[7, y] = shade(base, 34) + (255,)
        if px[8, y][3]: px[8, y] = shade(base, 10) + (255,)
    save(img, "crocodile_scale")
    # escama de titanoboa: grande, verde oscuro con borde dorado
    m, d = new_mask(); d.ellipse([2, 1, 13, 14], fill=255); d.polygon([(8, 0), (13, 6), (8, 15), (3, 6)], fill=255)
    base = (52, 84, 46)
    img = sprite(m, scale_fill(base, 3, -16, 20), outline_color=(150, 118, 30))
    px = img.load()
    gold = (232, 196, 80)
    for (x, y) in ((8, 3), (8, 4), (7, 6), (9, 6), (8, 8), (6, 9), (10, 9), (8, 11)):
        if px[x, y][3]: px[x, y] = gold + (255,)
    for y in range(2, 13):   # rim dorado interior
        for x in range(16):
            if px[x, y][3] and px[x, y][:3] == (150, 118, 30): px[x, y] = (205, 165, 52, 255)
    save(img, "titanoboa_scale")


# ---------------------------------------------------------------- baba de gecko
def slime():
    m, d = new_mask(); d.ellipse([3, 5, 12, 14], fill=255); d.ellipse([5, 2, 10, 7], fill=255)
    base = (118, 206, 84)
    def fill(x, y):
        t = (y - 2) / 12.0
        return mix((170, 236, 120), (84, 170, 60), t)
    img = sprite(m, fill, outline_color=(52, 118, 46), lit=36, dark=-30)
    px = img.load()
    for (x, y) in ((5, 8), (6, 7), (5, 9)):
        px[x, y] = (232, 255, 214, 255)
    px[9, 11] = (60, 130, 52, 255); px[10, 10] = (60, 130, 52, 255)
    save(img, "gecko_slime")


# ---------------------------------------------------------------- carnes
def meat(name, shape, raw):
    m, d = new_mask()
    bone = None
    if shape == "snake":          # tira ondulada
        d.line([(2, 12), (5, 8), (8, 10), (11, 6), (14, 3)], fill=255, width=4)
    elif shape == "croc":         # filete grueso
        d.ellipse([2, 3, 13, 13], fill=255)
    elif shape == "gecko":        # muslito pequeño
        d.ellipse([3, 4, 9, 10], fill=255); d.line([(8, 9), (12, 13)], fill=255, width=1); bone = [(9, 10), (11, 12), (12, 13), (13, 13), (12, 14)]
    else:                         # iguana: muslo con hueso
        d.ellipse([2, 2, 10, 10], fill=255); d.line([(8, 8), (13, 13)], fill=255, width=2); bone = [(9, 9), (10, 10), (11, 11), (12, 12), (13, 13), (14, 13), (13, 14)]
    pal = {"snake": ((222, 150, 142), (248, 196, 188)), "croc": ((206, 118, 112), (240, 168, 158)),
           "gecko": ((234, 168, 154), (252, 208, 196)), "iguana": ((226, 140, 128), (250, 186, 174))}
    base, hi = pal[shape]
    if not raw:
        base, hi = mix(base, (150, 84, 46), 0.78), mix(hi, (196, 128, 72), 0.7)
    rng = random.Random(name)
    def fill(x, y):
        if raw:
            # fibras diagonales claras
            return hi if (x + 2 * y) % 5 == 0 else (shade(base, -8) if (x + y) % 7 == 0 else base)
        # marcas de parrilla
        return shade(base, -34) if (x + y) % 6 in (0, 1) and (x * 3 + y) % 4 != 0 else (hi if (x - y) % 8 == 0 else base)
    img = sprite(m, fill, outline_color=shade(base, -88) if raw else (88, 46, 22))
    px = img.load()
    if bone:
        for (x, y) in bone:
            px[x, y] = (238, 232, 214, 255)
        px[bone[-1][0], bone[-1][1]] = (214, 208, 190, 255)
    save(img, name)


def meats():
    for shape, raw_name, cooked_name in (("snake", "snake_meat", "cooked_snake_meat"),
                                         ("croc", "crocodile_meat", "cooked_crocodile_meat"),
                                         ("gecko", "gecko_meat", "cooked_gecko_meat"),
                                         ("iguana", "iguana_meat", "cooked_iguana_meat")):
        meat(raw_name, shape, True)
        meat(cooked_name, shape, False)


# ---------------------------------------------------------------- armaduras
MATERIALS = {
    "snake_scale": dict(base=(96, 132, 62), trim=None),
    "crocodile_scale": dict(base=(66, 86, 62), trim=(168, 168, 150)),
    "titanoboa_scale": dict(base=(54, 88, 48), trim=(222, 184, 70)),
}


def armor_mask(kind):
    m, d = new_mask()
    if kind == "helmet":
        d.ellipse([3, 2, 12, 11], fill=255); d.rectangle([3, 6, 12, 13], fill=255)
        d.rectangle([5, 8, 10, 11], fill=0); d.rectangle([7, 8, 8, 12], fill=255); d.rectangle([6, 12, 9, 13], fill=0)
    elif kind == "chestplate":
        d.rectangle([4, 3, 11, 14], fill=255); d.rectangle([1, 2, 4, 6], fill=255); d.rectangle([11, 2, 14, 6], fill=255)
        d.rectangle([2, 6, 3, 9], fill=255); d.rectangle([12, 6, 13, 9], fill=255); d.rectangle([6, 2, 9, 3], fill=0)
    elif kind == "leggings":
        d.rectangle([3, 2, 12, 6], fill=255); d.rectangle([3, 6, 6, 14], fill=255); d.rectangle([9, 6, 12, 14], fill=255)
        d.rectangle([6, 6, 9, 8], fill=255)
    else:
        d.rectangle([2, 4, 6, 9], fill=255); d.rectangle([1, 9, 7, 12], fill=255)
        d.rectangle([9, 4, 13, 9], fill=255); d.rectangle([8, 9, 14, 12], fill=255)
    return m


def armor_icons():
    for mat, spec in MATERIALS.items():
        base = spec["base"]
        for kind in ("helmet", "chestplate", "leggings", "boots"):
            img = sprite(armor_mask(kind), scale_fill(base, 3, -22, 16), outline_delta=-90)
            px = img.load()
            trim = spec["trim"]
            if trim:
                rows = {"helmet": (6,), "chestplate": (2, 13), "leggings": (2, 3), "boots": (9,)}[kind]
                for y in rows:
                    for x in range(16):
                        if px[x, y][3] and px[x, y][:3] != shade(base, -90)[:3]:
                            c = px[x, y][:3]
                            if sum(abs(c[i] - shade(base, -90)[i]) for i in range(3)) > 60:
                                px[x, y] = trim + (255,)
            save(img, f"{mat}_{kind}")


def armor_layers():
    for mat, spec in MATERIALS.items():
        for leggings in (False, True):
            base = shade(spec["base"], -16) if leggings else spec["base"]
            f = scale_fill(base, 4, -22, 18)
            rng = random.Random(mat + str(leggings))
            img = Image.new("RGBA", (64, 32))
            px = img.load()
            for y in range(32):
                for x in range(64):
                    c = f(x, y)
                    # degradado vertical: más oscuro abajo
                    c = shade(c, int(8 - 16 * y / 32) + rng.randint(-4, 4))
                    px[x, y] = c + (255,)
            if spec["trim"]:   # franja dorada/clara en bordes de las piezas
                for x in range(64):
                    for y in (0, 15, 16, 31):
                        px[x, y] = spec["trim"] + (255,)
            sub = "humanoid_leggings" if leggings else "humanoid"
            out = os.path.join(A, "textures/entity/equipment", sub, mat + ".png")
            os.makedirs(os.path.dirname(out), exist_ok=True)
            img.save(out)


# ---------------------------------------------------------------- spawn eggs
def spawn_egg(name, c1, c2):
    m, d = new_mask(); d.ellipse([3, 1, 12, 14], fill=255); d.polygon([(8, 0), (12, 5), (11, 12), (5, 12), (4, 5)], fill=255)
    rng = random.Random(name)
    spots = {(rng.randint(4, 11), rng.randint(3, 12)) for _ in range(9)}
    def fill(x, y):
        return c2 if ((x, y) in spots or (x + 1, y) in spots) else c1
    img = sprite(m, fill, outline_delta=-90, lit=40, dark=-32)
    px = img.load()
    for (x, y) in ((5, 4), (6, 3), (5, 5)):
        if px[x, y][3]: px[x, y] = (255, 255, 255, 255)
    save(img, name + "_spawn_egg")


def write_all(egg_colors):
    scale_items()
    slime()
    meats()
    armor_icons()
    armor_layers()
    for name, (c1, c2) in egg_colors.items():
        spawn_egg(name, c1, c2)


if __name__ == "__main__":
    print("usa gen_assets.py")
