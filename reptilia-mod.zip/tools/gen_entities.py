#!/usr/bin/env python3
"""Fuente única de la forma de los 10 reptiles.
De aquí salen (siempre sincronizados):
  - src/main/java/com/reptilia/client/model/ReptileLayers.java  (los modelos)
  - src/main/resources/assets/reptilia/textures/entity/<animal>.png
Unidades: píxeles de modelo (16 px = 1 bloque). Suelo en y=24, frente del animal hacia -z.
"""
import math, os, random
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JAVA_OUT = os.path.join(ROOT, "src/main/java/com/reptilia/client/model/ReptileLayers.java")
TEX_OUT = os.path.join(ROOT, "src/main/resources/assets/reptilia/textures/entity")


def clamp(v): return max(0, min(255, int(v)))
def shade(c, d): return (clamp(c[0] + d), clamp(c[1] + d), clamp(c[2] + d))
def mix(a, b, t): return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))


# ---------------------------------------------------------------- paletas
def pal(base, alt, pat, eye, belly_t=0.55, accent=None):
    return dict(base=base, alt=alt, pat=pat, eye=eye,
                belly=mix(base, (236, 226, 190), belly_t), accent=accent or alt)

SPECIES = {
    "titanoboa":      dict(pal((78, 68, 38), (40, 32, 16), "diamond", (240, 200, 50)), kind="snake", cell=4, sway=6.0, shadow=1.4),
    "anaconda":       dict(pal((62, 90, 42), (26, 42, 20), "spots", (225, 185, 40)), kind="snake", cell=4, sway=4.0, shadow=0.9),
    "king_cobra":     dict(pal((124, 108, 62), (62, 50, 28), "bands", (205, 160, 30)), kind="snake", cell=2, sway=2.5, shadow=0.5),
    "rattlesnake":    dict(pal((182, 152, 102), (104, 72, 40), "diamond", (215, 170, 40)), kind="snake", cell=2, sway=2.2, shadow=0.4),
    "black_mamba":    dict(pal((76, 74, 68), (52, 50, 46), "plain", (205, 205, 60), 0.35), kind="snake", cell=2, sway=2.5, shadow=0.4),
    "nile_crocodile": dict(pal((86, 102, 62), (46, 58, 34), "blotch", (235, 205, 60)), kind="quad", cell=3, sway=0, shadow=0.9),
    "caiman":         dict(pal((52, 94, 50), (158, 154, 62), "bands", (235, 185, 40)), kind="quad", cell=3, sway=0, shadow=0.55),
    "alligator":      dict(pal((42, 54, 46), (92, 102, 88), "blotch", (225, 175, 40), 0.35), kind="quad", cell=3, sway=0, shadow=0.8),
    "iguana":         dict(pal((90, 170, 62), (48, 108, 40), "bands", (235, 150, 30), 0.5, accent=(226, 140, 70)), kind="quad", cell=3, sway=0, shadow=0.3),
    "gecko":          dict(pal((152, 178, 100), (216, 152, 72), "spots", (255, 225, 60), 0.6, accent=(238, 204, 160)), kind="quad", cell=2, sway=0, shadow=0.12),
}


# ---------------------------------------------------------------- piezas
def P(name, pivot, boxes, parent=None):
    return dict(name=name, pivot=pivot, boxes=boxes, parent=parent)

def B(key, origin, size, role):
    return dict(key=key, o=origin, size=size, role=role)


def build_snake(head, t, s, n, tails, hood=None, rattle=None):
    hw, hh, hd = head
    segs = [(t, s, "body", "body")] * n
    for i, (tt, ss) in enumerate(tails):
        segs.append((tt, ss, f"tail{i}", "tail"))
    if rattle:
        segs.append((rattle[0], rattle[1], "rattle", "rattle"))
    total = hd + sum(x[1] for x in segs)
    z = -total / 2
    parts = [P("head", (0, 24 - hh / 2, z + hd / 2), [B("head", (-hw / 2, -hh / 2, -hd / 2), (hw, hh, hd), "head")])]
    z += hd
    centers = []
    for i, (tt, ss, key, role) in enumerate(segs):
        parts.append(P(f"seg{i}", (0, 24 - tt / 2, z + ss / 2), [B(key, (-tt / 2, -tt / 2, -ss / 2), (tt, tt, ss), role)]))
        centers.append(z + ss / 2)
        z += ss
    if hood:
        parts.append(P("hood", (0, 24 - t, centers[0]), [B("hood", (-hood[0] / 2, -hood[1], -1), (hood[0], hood[1], 2), "hood")]))
    return parts


def build_quad(body, leg_t, leg_h, foot, head_pivot_dz, skull_h, head_boxes, tails, back_boxes=(),
               foot_role="foot", tail_top_align=True, tail_extras=None, leg_in=0.5):
    bw, bh, bl = body
    by = 24 - leg_h - bh / 2
    parts = [P("body", (0, by, 0), [B("body", (-bw / 2, -bh / 2, -bl / 2), (bw, bh, bl), "body")] + list(back_boxes))]
    parts.append(P("head", (0, by + bh / 2 - skull_h / 2, -bl / 2 + head_pivot_dz), head_boxes))
    lx = bw / 2 + leg_t / 2 - leg_in
    zf = -bl / 2 + leg_t / 2 + 1
    zb = bl / 2 - leg_t / 2 - 1
    fw, fd = foot
    for nm, x, z in (("leg_fl", lx, zf), ("leg_fr", -lx, zf), ("leg_bl", lx, zb), ("leg_br", -lx, zb)):
        parts.append(P(nm, (x, 24 - leg_h, z), [
            B("leg", (-leg_t / 2, 0, -leg_t / 2), (leg_t, leg_h - 1, leg_t), "leg"),
            B("foot", (-fw / 2, leg_h - 1, leg_t / 2 - fd), (fw, 1, fd), foot_role)]))
    prev, prev_h, prev_l = None, None, None
    for i, (w, h, l) in enumerate(tails):
        if i == 0:
            y = by - bh / 2 + h / 2 if tail_top_align else by
            piv = (0, y, bl / 2 - 1)
        else:
            piv = (0, ((h - prev_h) / 2) if tail_top_align else 0, prev_l)
        boxes = [B(f"tail{i}", (-w / 2, -h / 2, 0), (w, h, l), "tail")]
        if tail_extras and i in tail_extras:
            boxes += tail_extras[i](w, h, l)
        parts.append(P(f"tail{i}", piv, boxes, parent=f"tail{i-1}" if i else None))
        prev_h, prev_l = h, l
    return parts


def croc_head_nile():
    return [B("skull", (-4, -3, -6), (8, 6, 6), "head"),
            B("snout", (-3, -3, -15), (6, 3, 9), "head"),
            B("jaw", (-3, 1, -15), (6, 2, 14), "jaw"),
            B("tooth", (-3, 0, -15), (1, 1, 9), "tooth"),
            B("tooth", (2, 0, -15), (1, 1, 9), "tooth"),
            B("ridge", (-2, -4, -15), (4, 1, 2), "ridge"),
            B("eye", (-3, -4, -5), (2, 1, 2), "eye"),
            B("eye", (1, -4, -5), (2, 1, 2), "eye")]

def croc_head_alligator():
    return [B("skull", (-4.5, -2.5, -6), (9, 5, 6), "head"),
            B("snout", (-4, -2.5, -13), (8, 3, 7), "head"),
            B("snout_tip", (-3, -2.5, -15), (6, 3, 2), "head"),
            B("jaw", (-3.5, 0.5, -14), (7, 2, 12), "jaw"),
            B("nostril", (-2.5, -3.5, -14.5), (1, 1, 1), "nostril"),
            B("nostril", (1.5, -3.5, -14.5), (1, 1, 1), "nostril"),
            B("eye", (-4, -3.5, -4), (2, 1, 2), "eye"),
            B("eye", (2, -3.5, -4), (2, 1, 2), "eye")]

def croc_head_caiman():
    return [B("skull", (-3, -2, -5), (6, 4, 5), "head"),
            B("snout", (-2, -2, -10), (4, 2, 5), "head"),
            B("jaw", (-2, 0, -10), (4, 2, 7), "jaw"),
            B("ridge", (-1, -3, -5), (2, 1, 4), "ridge"),
            B("eye", (-3, -3, -4), (2, 1, 2), "eye"),
            B("eye", (1, -3, -4), (2, 1, 2), "eye")]

def iguana_head():
    return [B("skull", (-2, -2, -4), (4, 4, 4), "head"),
            B("snout", (-1.5, -1, -7), (3, 3, 3), "head"),
            B("dewlap", (-0.5, 2, -6), (1, 3, 4), "dewlap"),
            B("spine", (-0.5, -4, -3), (1, 2, 1), "spine"),
            B("spine", (-0.5, -4, -1), (1, 2, 1), "spine")]

def gecko_head():
    return [B("skull", (-2, -1.5, -4), (4, 3, 4), "head"),
            B("snout", (-1.5, -0.5, -6), (3, 2, 2), "head"),
            B("eye", (-2.5, -2.5, -3.5), (1, 1, 1), "eye"),
            B("eye", (1.5, -2.5, -3.5), (1, 1, 1), "eye")]


def scutes(bw, bh, bl, rows, k, y_extra=0):
    out = []
    for i in range(k):
        z = -bl / 2 + 1.5 + i * (bl - 3) / max(1, k - 1) - 1
        for x in rows:
            out.append(B("scute", (x - 1, -bh / 2 - 1 - y_extra, z), (2, 1, 2), "scute"))
    return out


def iguana_spines(bh, bl):
    return [B("spine", (-0.5, -bh / 2 - 2, -bl / 2 + 1 + i * 1.25), (1, 2, 1), "spine") for i in range(7)]


GEOMETRY = {
    "titanoboa":   lambda: build_snake((16, 12, 20), 18, 7, 9, [(14, 7), (10, 7), (7, 7)]),
    "anaconda":    lambda: build_snake((10, 7, 12), 11, 6, 8, [(9, 6), (6, 6)]),
    "king_cobra":  lambda: build_snake((5, 4, 7), 4, 5, 8, [(3, 5), (2, 5)], hood=(10, 8)),
    "rattlesnake": lambda: build_snake((5, 3, 6), 4, 4, 7, [(3, 4), (2, 4)], rattle=(3, 4)),
    "black_mamba": lambda: build_snake((4, 3, 8), 3, 5, 9, [(2, 5), (2, 5), (1, 5)]),
    "nile_crocodile": lambda: build_quad((10, 6, 18), 3, 4, (5, 5), 1, 6, croc_head_nile(),
                                         [(8, 5, 9), (6, 4, 9), (4, 3, 9)],
                                         back_boxes=scutes(10, 6, 18, (-2, 2), 5)),
    "alligator":   lambda: build_quad((11, 6, 17), 3, 4, (5, 5), 1, 5, croc_head_alligator(),
                                      [(9, 5, 8), (7, 4, 8), (4, 3, 8)],
                                      back_boxes=scutes(11, 6, 17, (-2, 2), 5)),
    "caiman":      lambda: build_quad((7, 4, 12), 2, 3, (4, 4), 1, 4, croc_head_caiman(),
                                      [(5, 3, 7), (4, 3, 7), (2, 2, 7)],
                                      back_boxes=scutes(7, 4, 12, (0,), 5)),
    "iguana":      lambda: build_quad((5, 4, 9), 2, 4, (3, 3), 1, 4, iguana_head(),
                                      [(3, 3, 6), (2, 2, 6), (2, 2, 6), (1, 1, 5)],
                                      back_boxes=iguana_spines(4, 9), tail_top_align=False,
                                      tail_extras={0: lambda w, h, l: [B("spine", (-0.5, -h / 2 - 2, 1), (1, 2, 1), "spine"),
                                                                       B("spine", (-0.5, -h / 2 - 2, 3.5), (1, 2, 1), "spine")],
                                                   1: lambda w, h, l: [B("spine", (-0.5, -h / 2 - 2, 1.5), (1, 2, 1), "spine")]}),
    "gecko":       lambda: build_quad((3, 2, 6), 1, 2, (3, 3), 1, 3, gecko_head(),
                                      [(2, 2, 4), (2, 1, 4), (1, 1, 4)], foot_role="pad", tail_top_align=False, leg_in=0.0),
}


# ---------------------------------------------------------------- UV y pintura
def unwrap(size):
    w, h, d = size
    return int(2 * (w + d)), int(d + h)


def try_pack(sizes, W, H):
    items = sorted(sizes.items(), key=lambda kv: -kv[1][1])
    x = y = rowh = 0
    pos = {}
    for k, (w, h) in items:
        if w > W:
            return None
        if x + w > W:
            x, y, rowh = 0, y + rowh, 0
        if y + h > H:
            return None
        pos[k] = (x, y)
        x += w
        rowh = max(rowh, h)
    return pos


def pack(sizes):
    for W, H in ((64, 32), (64, 64), (128, 64), (128, 128), (256, 128), (256, 256)):
        pos = try_pack(sizes, W, H)
        if pos:
            return W, H, pos
    raise RuntimeError("no cabe la textura")


def pattern_color(kind, x, y, base, alt):
    if kind == "diamond":
        d = abs((x % 10) - 5) + abs((y % 10) - 5)
        if d < 3:
            return alt
        return shade(base, 26) if d == 3 else (shade(base, -10) if d == 4 else base)
    if kind == "spots":
        h = (x * 73856093 ^ y * 19349663) & 0xFF
        return alt if h < 22 else base
    if kind == "bands":
        k = ((x + y // 2) // 3) % 3
        return alt if k == 0 else (shade(base, 16) if k == 1 else base)
    if kind == "blotch":
        v = math.sin(x * 0.55) + math.cos(y * 0.75) + math.sin((x + y) * 0.3)
        if v > 1.15:
            return alt
        return shade(base, 18) if v > 0.9 else base
    return base


def face_color(sp, role, face, lx, ly, fw, fh, ax, ay, rng):
    base, alt, belly, accent = sp["base"], sp["alt"], sp["belly"], sp["accent"]
    j = rng.randint(-8, 8)
    if role == "tooth":
        return shade((232, 228, 205), rng.randint(-10, 4))
    if role == "eye":
        if face in ("front", "top") and lx == fw // 2 and ly == fh // 2:
            return (14, 14, 14)
        return shade(sp["eye"], j // 2)
    if role == "nostril":
        return (22, 24, 20)
    if role == "dewlap":
        return shade(accent, j) if (ay // 2) % 2 == 0 else shade(accent, j - 22)
    if role == "pad":
        return shade(accent, j)
    if role == "spine":
        return shade(alt, 12 + j) if ly < fh // 2 else shade(base, j)
    if role == "rattle":
        return shade((200, 176, 120), j) if (ay // 2) % 2 == 0 else shade((140, 112, 70), j)
    if role == "ridge":
        return shade(base, 22 + j)
    if role == "jaw":
        return shade(belly, j - 6)
    if role == "hood":
        if face in ("front", "back"):
            if abs(lx - fw / 2) < fw * 0.28 and abs(ly - fh * 0.4) < fh * 0.2:   # mancha del capucho
                return shade(alt, j)
            return shade(pattern_color(sp["pat"], ax, ay, base, alt), j)
        return shade(base, j)
    # roles principales: body, head, tail, leg, foot, scute
    if face == "bottom":
        return shade(belly, j // 2 + (6 if (ax + ay) % 3 == 0 else -4))
    c = pattern_color(sp["pat"], ax, ay, base, alt)
    if role == "scute":
        c = shade(alt, -6) if (lx + ly) % 2 == 0 else shade(base, -22)
    elif role == "foot":
        c = shade(c, -20)
    elif role == "leg":
        c = shade(c, -8)
    if role in ("body", "tail", "head", "leg", "foot", "scute"):
        # escamas: borde oscuro y brillo en cada una, filas desfasadas
        cell = sp["cell"]
        off = (cell // 2) if (ay // cell) % 2 else 0
        cx, cy = (ax + off) % cell, ay % cell
        if cx == 0 or cy == 0:
            c = shade(c, -20)
        elif cx == 1 and cy == 1:
            c = shade(c, 14)
        # volumen: la cara superior se oscurece hacia los bordes del lomo
        if face == "top" and fw > 2:
            t = abs((lx + 0.5) / fw - 0.5) * 2
            c = shade(c, int(-22 * t * t))
    if face in ("left", "right", "front", "back") and role in ("body", "tail", "head"):
        t = (ly + 0.5) / max(1, fh)
        k = max(0.0, min(1.0, (t - 0.55) / 0.35))      # degradado suave hacia el vientre
        c = mix(c, belly, k * (0.9 if sp["kind"] == "snake" else 0.65))
    return shade(c, j // 2)


def paint_box(px, u, v, size, role, sp, rng, key=""):
    w, h, d = [int(x) for x in size]
    faces = {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d), "right": (u, v + d, d, h),
             "front": (u + d, v + d, w, h), "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h)}
    for face, (fx, fy, fw, fh) in faces.items():
        for yy in range(fh):
            for xx in range(fw):
                px[fx + xx, fy + yy] = face_color(sp, role, face, xx, yy, fw, fh, fx + xx, fy + yy, rng) + (255,)
    if role == "head" and key in ("head", "skull"):
        paint_head_details(px, u, v, w, h, d, sp)


def paint_head_details(px, u, v, w, h, d, sp):
    eye, dark = sp["eye"], (12, 12, 12)
    if sp["kind"] == "snake" or sp["name"] in ("iguana", "gecko"):
        ey = v + d + max(0, h // 3)
        if d >= 3:
            px[u + d - 2, ey] = eye + (255,)
            px[u + d - 1, ey] = dark + (255,)
            px[u + d + w + 1, ey] = eye + (255,)
            px[u + d + w, ey] = dark + (255,)
    if sp["kind"] == "snake" and h >= 3:   # boca y fosas nasales en la cara frontal
        for xx in range(w):
            px[u + d + xx, v + d + (h * 2) // 3] = (46, 30, 28, 255)
        px[u + d + w // 4, v + d + h // 3] = dark + (255,)
        px[u + d + w - 1 - w // 4, v + d + h // 3] = dark + (255,)


# ---------------------------------------------------------------- Java
def f(x):
    return f"{float(x):.1f}F"


def emit_layer(name, parts, W, H, uv):
    lines = [f"\tprivate static LayerDefinition {camel(name)}() {{",
             "\t\tMeshDefinition mesh = new MeshDefinition();",
             "\t\tPartDefinition root = mesh.getRoot();"]
    var = {None: "root"}
    for p in parts:
        cube = "CubeListBuilder.create()"
        for b in p["boxes"]:
            u, v = uv[b["key"]]
            ox, oy, oz = b["o"]
            w, h, d = b["size"]
            cube += f".texOffs({u}, {v}).addBox({f(ox)}, {f(oy)}, {f(oz)}, {f(w)}, {f(h)}, {f(d)})"
        if p["parent"] is None:
            piv = p["pivot"]
        else:
            piv = p["pivot"]   # ya es relativo al padre
        vname = "p_" + p["name"]
        lines.append(f"\t\tPartDefinition {vname} = {var[p['parent']]}.addOrReplaceChild(\"{p['name']}\", {cube}, "
                     f"PartPose.offset({f(piv[0])}, {f(piv[1])}, {f(piv[2])}));")
        var[p["name"]] = vname
    lines.append(f"\t\treturn LayerDefinition.create(mesh, {W}, {H});")
    lines.append("\t}\n")
    return "\n".join(lines)


def camel(name):
    parts = name.split("_")
    return parts[0] + "".join(x.title() for x in parts[1:])


def generate():
    os.makedirs(TEX_OUT, exist_ok=True)
    methods, infos, cases = [], [], []
    for name, sp in SPECIES.items():
        sp["name"] = name
        parts = GEOMETRY[name]()
        sizes, roles = {}, {}
        for p in parts:
            for b in p["boxes"]:
                s = unwrap(b["size"])
                if b["key"] in sizes and sizes[b["key"]] != s:
                    raise RuntimeError(f"{name}: la caja '{b['key']}' tiene medidas distintas")
                sizes[b["key"]] = s
                roles.setdefault(b["key"], (b["size"], b["role"]))
        W, H, uv = pack(sizes)
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        px = img.load()
        rng = random.Random(name)
        for key, (u, v) in uv.items():
            size, role = roles[key]
            paint_box(px, u, v, size, role, sp, rng, key)
        img.save(os.path.join(TEX_OUT, name + ".png"))
        methods.append(emit_layer(name, parts, W, H, uv))
        infos.append(f'\t\tnew Info("{name}", {"true" if sp["kind"] == "snake" else "false"}, {f(sp["sway"])}, {f(sp["shadow"])})')
        cases.append(f'\t\t\tcase "{name}" -> {camel(name)}();')
        print(f"{name:15s} textura {W}x{H}  piezas {len(parts)}")
    java = f'''package com.reptilia.client.model;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** GENERADO por tools/gen_entities.py: no editar a mano. */
public final class ReptileLayers {{
	public record Info(String name, boolean snake, float sway, float shadow) {{}}

	public static final Info[] ALL = {{
{(","+chr(10)).join(infos)}
	}};

	public static LayerDefinition create(String name) {{
		return switch (name) {{
{chr(10).join(cases)}
			default -> throw new IllegalArgumentException(name);
		}};
	}}

{chr(10).join(methods)}
	private ReptileLayers() {{}}
}}
'''
    with open(JAVA_OUT, "w", encoding="utf-8") as fh:
        fh.write(java)


if __name__ == "__main__":
    generate()
