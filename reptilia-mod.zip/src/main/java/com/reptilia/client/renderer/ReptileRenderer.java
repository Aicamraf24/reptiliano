package com.reptilia.client.renderer;

import com.reptilia.client.model.ReptileRenderState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import com.reptilia.entity.ReptileEntity;

/** Renderer compartido: cada animal le pasa su propio modelo y su propia textura. */
public class ReptileRenderer extends MobRenderer<ReptileEntity, ReptileRenderState, EntityModel<ReptileRenderState>> {
	private final Identifier texture;

	public ReptileRenderer(EntityRendererProvider.Context context, EntityModel<ReptileRenderState> model,
			Identifier texture, float shadowRadius) {
		super(context, model, shadowRadius);
		this.texture = texture;
	}

	@Override
	public ReptileRenderState createRenderState() {
		return new ReptileRenderState();
	}

	@Override
	public Identifier getTextureLocation(ReptileRenderState state) {
		return this.texture;
	}
}
