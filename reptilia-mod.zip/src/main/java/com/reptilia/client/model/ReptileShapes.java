package com.reptilia.client.model;

/**
 * Medidas (en píxeles de modelo, 16 px = 1 bloque) de cada animal.
 * Si cambias algo aquí, cambia también tools/gen_assets.py para que las texturas coincidan.
 */
public final class ReptileShapes {
	/** Lagarto/cocodrilo de cuatro patas. Textura 128x64. */
	public record Lizard(int headW, int headH, int headD,
			int bodyW, int bodyH, int bodyL,
			int tail1W, int tail1H, int tail1L,
			int tail2W, int tail2H, int tail2L,
			int legT, int legH) {}

	/** Serpiente segmentada. Textura 128x64. */
	public record Snake(int headW, int headH, int headD,
			int segW, int segH, int segL, int segCount, float taper,
			int hoodW, int hoodH) {}

	// ---- Cuatro patas ----
	public static final Lizard NILE_CROCODILE = new Lizard(6, 4, 12, 10, 6, 20, 7, 4, 12, 4, 3, 10, 3, 4);
	public static final Lizard ALLIGATOR      = new Lizard(6, 4, 11, 10, 6, 18, 7, 4, 11, 4, 3, 9, 3, 4);
	public static final Lizard CAIMAN         = new Lizard(4, 3, 8, 7, 5, 14, 5, 3, 9, 3, 2, 8, 2, 3);
	public static final Lizard IGUANA         = new Lizard(4, 4, 6, 5, 4, 9, 3, 3, 9, 2, 2, 9, 2, 3);
	public static final Lizard GECKO          = new Lizard(3, 2, 4, 3, 2, 6, 2, 2, 5, 1, 1, 4, 1, 1);

	// ---- Serpientes ----
	public static final Snake TITANOBOA   = new Snake(10, 7, 14, 10, 8, 9, 9, 0.5f, 0, 0);
	public static final Snake ANACONDA    = new Snake(6, 4, 8, 6, 5, 7, 8, 0.5f, 0, 0);
	public static final Snake KING_COBRA  = new Snake(4, 3, 6, 3, 3, 6, 8, 0.6f, 8, 6);
	public static final Snake RATTLESNAKE = new Snake(4, 3, 6, 4, 3, 5, 7, 0.5f, 0, 0);
	public static final Snake BLACK_MAMBA = new Snake(3, 3, 6, 3, 3, 6, 9, 0.6f, 0, 0);

	private ReptileShapes() {}
}
