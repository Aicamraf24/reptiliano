package com.reptilia.client.model;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Serpiente hecha de segmentos que ondulan al moverse (la cobra lleva su capucha). */
public class SnakeModel extends EntityModel<ReptileRenderState> {
	private final ModelPart head;
	private final ModelPart[] segments;
	private final float[] baseZ;

	public SnakeModel(ModelPart root, int segmentCount) {
		super(root);
		this.head = root.getChild("head");
		this.segments = new ModelPart[segmentCount];
		this.baseZ = new float[segmentCount];
		for (int i = 0; i < segmentCount; i++) {
			this.segments[i] = root.getChild("seg" + i);
			this.baseZ[i] = this.segments[i].z;
		}
	}

	public static LayerDefinition create(ReptileShapes.Snake s) {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		float total = s.headD() + s.segL() * s.segCount();
		float zStart = -total / 2f;

		PartDefinition headDef = root.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-s.headW() / 2f, -s.headH() / 2f, -s.headD() / 2f, s.headW(), s.headH(), s.headD()),
				PartPose.offset(0f, 24f - s.headH() / 2f, zStart + s.headD() / 2f));

		if (s.hoodW() > 0) {
			// Capucha aplanada de la cobra, justo detrás de la cabeza
			headDef.addOrReplaceChild("hood",
					CubeListBuilder.create().texOffs(0, 24)
							.addBox(-s.hoodW() / 2f, -s.hoodH() / 2f, 0f, s.hoodW(), s.hoodH(), 1f),
					PartPose.offset(0f, -0.5f, s.headD() / 2f));
		}

		for (int i = 0; i < s.segCount(); i++) {
			float t = s.segCount() > 1 ? (float) i / (s.segCount() - 1) : 0f;
			float scale = 1f - s.taper() * t;
			float w = Math.max(1f, s.segW() * scale);
			float h = Math.max(1f, s.segH() * scale);
			float z = zStart + s.headD() + s.segL() * i + s.segL() / 2f;
			root.addOrReplaceChild("seg" + i,
					CubeListBuilder.create().texOffs(0, 24)
							.addBox(-w / 2f, -h / 2f, -s.segL() / 2f, w, h, s.segL()),
					PartPose.offset(0f, 24f - h / 2f, z));
		}
		return LayerDefinition.create(mesh, 128, 64);
	}

	@Override
	public void setupAnim(ReptileRenderState state) {
		super.setupAnim(state);
		float pos = state.walkAnimationPos * 0.9f;
		float amp = Math.min(state.walkAnimationSpeed * 2.5f, 1.0f);
		float idle = state.ageInTicks * 0.05f;

		this.head.xRot = (float) Math.toRadians(state.xRot) * 0.6f;
		this.head.x = wave(pos, idle, -1, amp);
		this.head.yRot = (float) Math.toRadians(state.yRot) * 0.6f + (float) Math.cos(pos + 0.7f) * 0.25f * amp;

		for (int i = 0; i < this.segments.length; i++) {
			this.segments[i].x = wave(pos, idle, i, amp);
			this.segments[i].yRot = (float) Math.cos(pos - i * 0.7f) * 0.30f * amp;
		}
	}

	private static float wave(float pos, float idle, int index, float amp) {
		float phase = pos - index * 0.7f;
		return (float) Math.sin(phase) * (1.2f + 2.6f * amp) * 0.6f
				+ (float) Math.sin(idle - index * 0.5f) * 0.4f;
	}
}
