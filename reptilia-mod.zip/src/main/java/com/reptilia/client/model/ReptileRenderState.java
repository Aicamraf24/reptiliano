package com.reptilia.client.model;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class ReptileRenderState extends LivingEntityRenderState {
}
