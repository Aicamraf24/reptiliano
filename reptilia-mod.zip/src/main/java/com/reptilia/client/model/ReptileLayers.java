package com.reptilia.client.model;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** GENERADO por tools/gen_entities.py: no editar a mano. */
public final class ReptileLayers {
	public record Info(String name, boolean snake, float sway, float shadow) {}

	public static final Info[] ALL = {
		new Info("titanoboa", true, 6.0F, 1.4F),
		new Info("anaconda", true, 4.0F, 0.9F),
		new Info("king_cobra", true, 2.5F, 0.5F),
		new Info("rattlesnake", true, 2.2F, 0.4F),
		new Info("black_mamba", true, 2.5F, 0.4F),
		new Info("nile_crocodile", false, 0.0F, 0.9F),
		new Info("caiman", false, 0.0F, 0.6F),
		new Info("alligator", false, 0.0F, 0.8F),
		new Info("iguana", false, 0.0F, 0.3F),
		new Info("gecko", false, 0.0F, 0.1F)
	};

	public static LayerDefinition create(String name) {
		return switch (name) {
			case "titanoboa" -> titanoboa();
			case "anaconda" -> anaconda();
			case "king_cobra" -> kingCobra();
			case "rattlesnake" -> rattlesnake();
			case "black_mamba" -> blackMamba();
			case "nile_crocodile" -> nileCrocodile();
			case "caiman" -> caiman();
			case "alligator" -> alligator();
			case "iguana" -> iguana();
			case "gecko" -> gecko();
			default -> throw new IllegalArgumentException(name);
		};
	}

	private static LayerDefinition titanoboa() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, -6.0F, -10.0F, 16.0F, 12.0F, 20.0F), PartPose.offset(0.0F, 18.0F, -42.0F));
		PartDefinition p_seg0 = root.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, -28.5F));
		PartDefinition p_seg1 = root.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, -21.5F));
		PartDefinition p_seg2 = root.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, -14.5F));
		PartDefinition p_seg3 = root.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, -7.5F));
		PartDefinition p_seg4 = root.addOrReplaceChild("seg4", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, -0.5F));
		PartDefinition p_seg5 = root.addOrReplaceChild("seg5", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, 6.5F));
		PartDefinition p_seg6 = root.addOrReplaceChild("seg6", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, 13.5F));
		PartDefinition p_seg7 = root.addOrReplaceChild("seg7", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, 20.5F));
		PartDefinition p_seg8 = root.addOrReplaceChild("seg8", CubeListBuilder.create().texOffs(72, 0).addBox(-9.0F, -9.0F, -3.5F, 18.0F, 18.0F, 7.0F), PartPose.offset(0.0F, 15.0F, 27.5F));
		PartDefinition p_seg9 = root.addOrReplaceChild("seg9", CubeListBuilder.create().texOffs(0, 32).addBox(-7.0F, -7.0F, -3.5F, 14.0F, 14.0F, 7.0F), PartPose.offset(0.0F, 17.0F, 34.5F));
		PartDefinition p_seg10 = root.addOrReplaceChild("seg10", CubeListBuilder.create().texOffs(42, 32).addBox(-5.0F, -5.0F, -3.5F, 10.0F, 10.0F, 7.0F), PartPose.offset(0.0F, 19.0F, 41.5F));
		PartDefinition p_seg11 = root.addOrReplaceChild("seg11", CubeListBuilder.create().texOffs(76, 32).addBox(-3.5F, -3.5F, -3.5F, 7.0F, 7.0F, 7.0F), PartPose.offset(0.0F, 20.5F, 48.5F));
		return LayerDefinition.create(mesh, 128, 64);
	}

	private static LayerDefinition anaconda() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -3.5F, -6.0F, 10.0F, 7.0F, 12.0F), PartPose.offset(0.0F, 20.5F, -30.0F));
		PartDefinition p_seg0 = root.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, -21.0F));
		PartDefinition p_seg1 = root.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, -15.0F));
		PartDefinition p_seg2 = root.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, -9.0F));
		PartDefinition p_seg3 = root.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, -3.0F));
		PartDefinition p_seg4 = root.addOrReplaceChild("seg4", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, 3.0F));
		PartDefinition p_seg5 = root.addOrReplaceChild("seg5", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, 9.0F));
		PartDefinition p_seg6 = root.addOrReplaceChild("seg6", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, 15.0F));
		PartDefinition p_seg7 = root.addOrReplaceChild("seg7", CubeListBuilder.create().texOffs(0, 19).addBox(-5.5F, -5.5F, -3.0F, 11.0F, 11.0F, 6.0F), PartPose.offset(0.0F, 18.5F, 21.0F));
		PartDefinition p_seg8 = root.addOrReplaceChild("seg8", CubeListBuilder.create().texOffs(34, 19).addBox(-4.5F, -4.5F, -3.0F, 9.0F, 9.0F, 6.0F), PartPose.offset(0.0F, 19.5F, 27.0F));
		PartDefinition p_seg9 = root.addOrReplaceChild("seg9", CubeListBuilder.create().texOffs(0, 36).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offset(0.0F, 21.0F, 33.0F));
		return LayerDefinition.create(mesh, 64, 64);
	}

	private static LayerDefinition kingCobra() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-2.5F, -2.0F, -3.5F, 5.0F, 4.0F, 7.0F), PartPose.offset(0.0F, 22.0F, -25.0F));
		PartDefinition p_seg0 = root.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, -19.0F));
		PartDefinition p_seg1 = root.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, -14.0F));
		PartDefinition p_seg2 = root.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, -9.0F));
		PartDefinition p_seg3 = root.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, -4.0F));
		PartDefinition p_seg4 = root.addOrReplaceChild("seg4", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, 1.0F));
		PartDefinition p_seg5 = root.addOrReplaceChild("seg5", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, 6.0F));
		PartDefinition p_seg6 = root.addOrReplaceChild("seg6", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, 11.0F));
		PartDefinition p_seg7 = root.addOrReplaceChild("seg7", CubeListBuilder.create().texOffs(0, 11).addBox(-2.0F, -2.0F, -2.5F, 4.0F, 4.0F, 5.0F), PartPose.offset(0.0F, 22.0F, 16.0F));
		PartDefinition p_seg8 = root.addOrReplaceChild("seg8", CubeListBuilder.create().texOffs(18, 11).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, 21.0F));
		PartDefinition p_seg9 = root.addOrReplaceChild("seg9", CubeListBuilder.create().texOffs(34, 11).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F), PartPose.offset(0.0F, 23.0F, 26.0F));
		PartDefinition p_hood = root.addOrReplaceChild("hood", CubeListBuilder.create().texOffs(24, 0).addBox(-5.0F, -8.0F, -1.0F, 10.0F, 8.0F, 2.0F), PartPose.offset(0.0F, 20.0F, -19.0F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	private static LayerDefinition rattlesnake() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-2.5F, -1.5F, -3.0F, 5.0F, 3.0F, 6.0F), PartPose.offset(0.0F, 22.5F, -20.0F));
		PartDefinition p_seg0 = root.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, -15.0F));
		PartDefinition p_seg1 = root.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, -11.0F));
		PartDefinition p_seg2 = root.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, -7.0F));
		PartDefinition p_seg3 = root.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, -3.0F));
		PartDefinition p_seg4 = root.addOrReplaceChild("seg4", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, 1.0F));
		PartDefinition p_seg5 = root.addOrReplaceChild("seg5", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, 5.0F));
		PartDefinition p_seg6 = root.addOrReplaceChild("seg6", CubeListBuilder.create().texOffs(22, 0).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F), PartPose.offset(0.0F, 22.0F, 9.0F));
		PartDefinition p_seg7 = root.addOrReplaceChild("seg7", CubeListBuilder.create().texOffs(38, 0).addBox(-1.5F, -1.5F, -2.0F, 3.0F, 3.0F, 4.0F), PartPose.offset(0.0F, 22.5F, 13.0F));
		PartDefinition p_seg8 = root.addOrReplaceChild("seg8", CubeListBuilder.create().texOffs(14, 9).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 2.0F, 4.0F), PartPose.offset(0.0F, 23.0F, 17.0F));
		PartDefinition p_seg9 = root.addOrReplaceChild("seg9", CubeListBuilder.create().texOffs(0, 9).addBox(-1.5F, -1.5F, -2.0F, 3.0F, 3.0F, 4.0F), PartPose.offset(0.0F, 22.5F, 21.0F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	private static LayerDefinition blackMamba() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -1.5F, -4.0F, 4.0F, 3.0F, 8.0F), PartPose.offset(0.0F, 22.5F, -30.0F));
		PartDefinition p_seg0 = root.addOrReplaceChild("seg0", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, -23.5F));
		PartDefinition p_seg1 = root.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, -18.5F));
		PartDefinition p_seg2 = root.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, -13.5F));
		PartDefinition p_seg3 = root.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, -8.5F));
		PartDefinition p_seg4 = root.addOrReplaceChild("seg4", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, -3.5F));
		PartDefinition p_seg5 = root.addOrReplaceChild("seg5", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, 1.5F));
		PartDefinition p_seg6 = root.addOrReplaceChild("seg6", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, 6.5F));
		PartDefinition p_seg7 = root.addOrReplaceChild("seg7", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, 11.5F));
		PartDefinition p_seg8 = root.addOrReplaceChild("seg8", CubeListBuilder.create().texOffs(24, 0).addBox(-1.5F, -1.5F, -2.5F, 3.0F, 3.0F, 5.0F), PartPose.offset(0.0F, 22.5F, 16.5F));
		PartDefinition p_seg9 = root.addOrReplaceChild("seg9", CubeListBuilder.create().texOffs(40, 0).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F), PartPose.offset(0.0F, 23.0F, 21.5F));
		PartDefinition p_seg10 = root.addOrReplaceChild("seg10", CubeListBuilder.create().texOffs(0, 11).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F), PartPose.offset(0.0F, 23.0F, 26.5F));
		PartDefinition p_seg11 = root.addOrReplaceChild("seg11", CubeListBuilder.create().texOffs(14, 11).addBox(-0.5F, -0.5F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offset(0.0F, 23.5F, 31.5F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	private static LayerDefinition nileCrocodile() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -3.0F, -9.0F, 10.0F, 6.0F, 18.0F).texOffs(78, 38).addBox(-3.0F, -4.0F, -8.5F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(1.0F, -4.0F, -8.5F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(-3.0F, -4.0F, -4.8F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(1.0F, -4.0F, -4.8F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(-3.0F, -4.0F, -1.0F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(1.0F, -4.0F, -1.0F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(-3.0F, -4.0F, 2.8F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(1.0F, -4.0F, 2.8F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(-3.0F, -4.0F, 6.5F, 2.0F, 1.0F, 2.0F).texOffs(78, 38).addBox(1.0F, -4.0F, 6.5F, 2.0F, 1.0F, 2.0F), PartPose.offset(0.0F, 17.0F, 0.0F));
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(64, 24).addBox(-4.0F, -3.0F, -6.0F, 8.0F, 6.0F, 6.0F).texOffs(92, 24).addBox(-3.0F, -3.0F, -15.0F, 6.0F, 3.0F, 9.0F).texOffs(56, 0).addBox(-3.0F, 1.0F, -15.0F, 6.0F, 2.0F, 14.0F).texOffs(26, 38).addBox(-3.0F, 0.0F, -15.0F, 1.0F, 1.0F, 9.0F).texOffs(26, 38).addBox(2.0F, 0.0F, -15.0F, 1.0F, 1.0F, 9.0F).texOffs(86, 38).addBox(-2.0F, -4.0F, -15.0F, 4.0F, 1.0F, 2.0F).texOffs(98, 38).addBox(-3.0F, -4.0F, -5.0F, 2.0F, 1.0F, 2.0F).texOffs(98, 38).addBox(1.0F, -4.0F, -5.0F, 2.0F, 1.0F, 2.0F), PartPose.offset(0.0F, 17.0F, -8.0F));
		PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(46, 38).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(58, 38).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(6.0F, 20.0F, -5.5F));
		PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(46, 38).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(58, 38).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(-6.0F, 20.0F, -5.5F));
		PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(46, 38).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(58, 38).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(6.0F, 20.0F, 5.5F));
		PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(46, 38).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(58, 38).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(-6.0F, 20.0F, 5.5F));
		PartDefinition p_tail0 = root.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(0, 24).addBox(-4.0F, -2.5F, 0.0F, 8.0F, 5.0F, 9.0F), PartPose.offset(0.0F, 16.5F, 8.0F));
		PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(34, 24).addBox(-3.0F, -2.0F, 0.0F, 6.0F, 4.0F, 9.0F), PartPose.offset(0.0F, -0.5F, 9.0F));
		PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, -1.5F, 0.0F, 4.0F, 3.0F, 9.0F), PartPose.offset(0.0F, -0.5F, 9.0F));
		return LayerDefinition.create(mesh, 128, 64);
	}

	private static LayerDefinition caiman() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.5F, -2.0F, -6.0F, 7.0F, 4.0F, 12.0F).texOffs(36, 35).addBox(-1.0F, -3.0F, -5.5F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-1.0F, -3.0F, -3.2F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-1.0F, -3.0F, 1.2F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-1.0F, -3.0F, 3.5F, 2.0F, 1.0F, 2.0F), PartPose.offset(0.0F, 19.0F, 0.0F));
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(22, 16).addBox(-3.0F, -2.0F, -5.0F, 6.0F, 4.0F, 5.0F).texOffs(40, 26).addBox(-2.0F, -2.0F, -10.0F, 4.0F, 2.0F, 5.0F).texOffs(0, 26).addBox(-2.0F, 0.0F, -10.0F, 4.0F, 2.0F, 7.0F).texOffs(0, 35).addBox(-1.0F, -3.0F, -5.0F, 2.0F, 1.0F, 4.0F).texOffs(44, 35).addBox(-3.0F, -3.0F, -4.0F, 2.0F, 1.0F, 2.0F).texOffs(44, 35).addBox(1.0F, -3.0F, -4.0F, 2.0F, 1.0F, 2.0F), PartPose.offset(0.0F, 19.0F, -5.0F));
		PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(28, 35).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(12, 35).addBox(-2.0F, 2.0F, -3.0F, 4.0F, 1.0F, 4.0F), PartPose.offset(4.0F, 21.0F, -3.0F));
		PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(28, 35).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(12, 35).addBox(-2.0F, 2.0F, -3.0F, 4.0F, 1.0F, 4.0F), PartPose.offset(-4.0F, 21.0F, -3.0F));
		PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(28, 35).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(12, 35).addBox(-2.0F, 2.0F, -3.0F, 4.0F, 1.0F, 4.0F), PartPose.offset(4.0F, 21.0F, 3.0F));
		PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(28, 35).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(12, 35).addBox(-2.0F, 2.0F, -3.0F, 4.0F, 1.0F, 4.0F), PartPose.offset(-4.0F, 21.0F, 3.0F));
		PartDefinition p_tail0 = root.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(38, 0).addBox(-2.5F, -1.5F, 0.0F, 5.0F, 3.0F, 7.0F), PartPose.offset(0.0F, 18.5F, 5.0F));
		PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, -1.5F, 0.0F, 4.0F, 3.0F, 7.0F), PartPose.offset(0.0F, 0.0F, 7.0F));
		PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(22, 26).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 7.0F), PartPose.offset(0.0F, -0.5F, 7.0F));
		return LayerDefinition.create(mesh, 64, 64);
	}

	private static LayerDefinition alligator() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5.5F, -3.0F, -8.5F, 11.0F, 6.0F, 17.0F).texOffs(36, 35).addBox(-3.0F, -4.0F, -8.0F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(1.0F, -4.0F, -8.0F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-3.0F, -4.0F, -4.5F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(1.0F, -4.0F, -4.5F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-3.0F, -4.0F, -1.0F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(1.0F, -4.0F, -1.0F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-3.0F, -4.0F, 2.5F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(1.0F, -4.0F, 2.5F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(-3.0F, -4.0F, 6.0F, 2.0F, 1.0F, 2.0F).texOffs(36, 35).addBox(1.0F, -4.0F, 6.0F, 2.0F, 1.0F, 2.0F), PartPose.offset(0.0F, 17.0F, 0.0F));
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(30, 23).addBox(-4.5F, -2.5F, -6.0F, 9.0F, 5.0F, 6.0F).texOffs(84, 23).addBox(-4.0F, -2.5F, -13.0F, 8.0F, 3.0F, 7.0F).texOffs(20, 35).addBox(-3.0F, -2.5F, -15.0F, 6.0F, 3.0F, 2.0F).texOffs(56, 0).addBox(-3.5F, 0.5F, -14.0F, 7.0F, 2.0F, 12.0F).texOffs(52, 35).addBox(-2.5F, -3.5F, -14.5F, 1.0F, 1.0F, 1.0F).texOffs(52, 35).addBox(1.5F, -3.5F, -14.5F, 1.0F, 1.0F, 1.0F).texOffs(44, 35).addBox(-4.0F, -3.5F, -4.0F, 2.0F, 1.0F, 2.0F).texOffs(44, 35).addBox(2.0F, -3.5F, -4.0F, 2.0F, 1.0F, 2.0F), PartPose.offset(0.0F, 17.5F, -7.5F));
		PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(114, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(0, 35).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(6.5F, 20.0F, -5.0F));
		PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(114, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(0, 35).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(-6.5F, 20.0F, -5.0F));
		PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(114, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(0, 35).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(6.5F, 20.0F, 5.0F));
		PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(114, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F).texOffs(0, 35).addBox(-2.5F, 3.0F, -3.5F, 5.0F, 1.0F, 5.0F), PartPose.offset(-6.5F, 20.0F, 5.0F));
		PartDefinition p_tail0 = root.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(94, 0).addBox(-4.5F, -2.5F, 0.0F, 9.0F, 5.0F, 8.0F), PartPose.offset(0.0F, 16.5F, 7.5F));
		PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(0, 23).addBox(-3.5F, -2.0F, 0.0F, 7.0F, 4.0F, 8.0F), PartPose.offset(0.0F, -0.5F, 8.0F));
		PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(60, 23).addBox(-2.0F, -1.5F, 0.0F, 4.0F, 3.0F, 8.0F), PartPose.offset(0.0F, -0.5F, 8.0F));
		return LayerDefinition.create(mesh, 128, 64);
	}

	private static LayerDefinition iguana() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.5F, -2.0F, -4.5F, 5.0F, 4.0F, 9.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, -3.5F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, -2.2F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, -1.0F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, 0.2F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, 1.5F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, 2.8F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, 4.0F, 1.0F, 2.0F, 1.0F), PartPose.offset(0.0F, 18.0F, 0.0F));
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(46, 0).addBox(-2.0F, -2.0F, -4.0F, 4.0F, 4.0F, 4.0F).texOffs(42, 13).addBox(-1.5F, -1.0F, -7.0F, 3.0F, 3.0F, 3.0F).texOffs(32, 13).addBox(-0.5F, 2.0F, -6.0F, 1.0F, 3.0F, 4.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, -3.0F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -4.0F, -1.0F, 1.0F, 2.0F, 1.0F), PartPose.offset(0.0F, 18.0F, -3.5F));
		PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(12, 21).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F).texOffs(20, 21).addBox(-1.5F, 3.0F, -2.0F, 3.0F, 1.0F, 3.0F), PartPose.offset(3.0F, 20.0F, -1.5F));
		PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(12, 21).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F).texOffs(20, 21).addBox(-1.5F, 3.0F, -2.0F, 3.0F, 1.0F, 3.0F), PartPose.offset(-3.0F, 20.0F, -1.5F));
		PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(12, 21).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F).texOffs(20, 21).addBox(-1.5F, 3.0F, -2.0F, 3.0F, 1.0F, 3.0F), PartPose.offset(3.0F, 20.0F, 1.5F));
		PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(12, 21).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F).texOffs(20, 21).addBox(-1.5F, 3.0F, -2.0F, 3.0F, 1.0F, 3.0F), PartPose.offset(-3.0F, 20.0F, 1.5F));
		PartDefinition p_tail0 = root.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(28, 0).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 6.0F).texOffs(32, 21).addBox(-0.5F, -3.5F, 1.0F, 1.0F, 2.0F, 1.0F).texOffs(32, 21).addBox(-0.5F, -3.5F, 3.5F, 1.0F, 2.0F, 1.0F), PartPose.offset(0.0F, 18.0F, 3.5F));
		PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(0, 13).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 6.0F).texOffs(32, 21).addBox(-0.5F, -3.0F, 1.5F, 1.0F, 2.0F, 1.0F), PartPose.offset(0.0F, 0.0F, 6.0F));
		PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(16, 13).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 6.0F), PartPose.offset(0.0F, 0.0F, 6.0F));
		PartDefinition p_tail3 = p_tail2.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(0, 21).addBox(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 5.0F), PartPose.offset(0.0F, 0.0F, 6.0F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	private static LayerDefinition gecko() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 2.0F, 6.0F), PartPose.offset(0.0F, 21.0F, 0.0F));
		PartDefinition p_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(18, 0).addBox(-2.0F, -1.5F, -4.0F, 4.0F, 3.0F, 4.0F).texOffs(10, 8).addBox(-1.5F, -0.5F, -6.0F, 3.0F, 2.0F, 2.0F).texOffs(32, 8).addBox(-2.5F, -2.5F, -3.5F, 1.0F, 1.0F, 1.0F).texOffs(32, 8).addBox(1.5F, -2.5F, -3.5F, 1.0F, 1.0F, 1.0F), PartPose.offset(0.0F, 20.5F, -2.0F));
		PartDefinition p_leg_fl = root.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(36, 8).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(20, 8).addBox(-1.5F, 1.0F, -2.5F, 3.0F, 1.0F, 3.0F), PartPose.offset(1.5F, 22.0F, -0.5F));
		PartDefinition p_leg_fr = root.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(36, 8).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(20, 8).addBox(-1.5F, 1.0F, -2.5F, 3.0F, 1.0F, 3.0F), PartPose.offset(-1.5F, 22.0F, -0.5F));
		PartDefinition p_leg_bl = root.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(36, 8).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(20, 8).addBox(-1.5F, 1.0F, -2.5F, 3.0F, 1.0F, 3.0F), PartPose.offset(1.5F, 22.0F, 0.5F));
		PartDefinition p_leg_br = root.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(36, 8).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(20, 8).addBox(-1.5F, 1.0F, -2.5F, 3.0F, 1.0F, 3.0F), PartPose.offset(-1.5F, 22.0F, 0.5F));
		PartDefinition p_tail0 = root.addOrReplaceChild("tail0", CubeListBuilder.create().texOffs(34, 0).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F), PartPose.offset(0.0F, 21.0F, 2.0F));
		PartDefinition p_tail1 = p_tail0.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(46, 0).addBox(-1.0F, -0.5F, 0.0F, 2.0F, 1.0F, 4.0F), PartPose.offset(0.0F, 0.0F, 4.0F));
		PartDefinition p_tail2 = p_tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(0, 8).addBox(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 4.0F), PartPose.offset(0.0F, 0.0F, 4.0F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	private ReptileLayers() {}
}
