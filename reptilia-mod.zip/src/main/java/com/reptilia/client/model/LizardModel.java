package com.reptilia.client.model;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Modelo de cuatro patas con cola articulada (cocodrilos, caimán, aligátor, iguana, gecko). */
public class LizardModel extends EntityModel<ReptileRenderState> {
	private final ModelPart head;
	private final ModelPart tail1;
	private final ModelPart tail2;
	private final ModelPart frontLeft;
	private final ModelPart frontRight;
	private final ModelPart backLeft;
	private final ModelPart backRight;

	public LizardModel(ModelPart root) {
		super(root);
		this.head = root.getChild("head");
		this.tail1 = root.getChild("tail1");
		this.tail2 = this.tail1.getChild("tail2");
		this.frontLeft = root.getChild("front_left");
		this.frontRight = root.getChild("front_right");
		this.backLeft = root.getChild("back_left");
		this.backRight = root.getChild("back_right");
	}

	public static LayerDefinition create(ReptileShapes.Lizard s) {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		float bodyY = 24f - s.legH() - s.bodyH() / 2f + 1f;

		root.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 20)
						.addBox(-s.bodyW() / 2f, -s.bodyH() / 2f, -s.bodyL() / 2f, s.bodyW(), s.bodyH(), s.bodyL()),
				PartPose.offset(0f, bodyY, 0f));

		root.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-s.headW() / 2f, -s.headH() / 2f, -s.headD(), s.headW(), s.headH(), s.headD()),
				PartPose.offset(0f, bodyY - (s.bodyH() - s.headH()) / 2f, -s.bodyL() / 2f));

		PartDefinition t1 = root.addOrReplaceChild("tail1",
				CubeListBuilder.create().texOffs(72, 0)
						.addBox(-s.tail1W() / 2f, -s.tail1H() / 2f, 0f, s.tail1W(), s.tail1H(), s.tail1L()),
				PartPose.offset(0f, bodyY + (s.bodyH() - s.tail1H()) / 2f, s.bodyL() / 2f));
		t1.addOrReplaceChild("tail2",
				CubeListBuilder.create().texOffs(72, 28)
						.addBox(-s.tail2W() / 2f, -s.tail2H() / 2f, 0f, s.tail2W(), s.tail2H(), s.tail2L()),
				PartPose.offset(0f, 0f, s.tail1L()));

		float legX = s.bodyW() / 2f + s.legT() / 2f - 1f;
		float legZFront = -s.bodyL() * 0.3f;
		float legZBack = s.bodyL() * 0.3f;
		float legY = 24f - s.legH();
		CubeListBuilder leg = CubeListBuilder.create().texOffs(50, 0)
				.addBox(-s.legT() / 2f, 0f, -s.legT() / 2f, s.legT(), s.legH(), s.legT());
		root.addOrReplaceChild("front_left", leg, PartPose.offset(legX, legY, legZFront));
		root.addOrReplaceChild("front_right", leg, PartPose.offset(-legX, legY, legZFront));
		root.addOrReplaceChild("back_left", leg, PartPose.offset(legX, legY, legZBack));
		root.addOrReplaceChild("back_right", leg, PartPose.offset(-legX, legY, legZBack));

		return LayerDefinition.create(mesh, 128, 64);
	}

	@Override
	public void setupAnim(ReptileRenderState state) {
		super.setupAnim(state);
		this.head.xRot = (float) Math.toRadians(state.xRot);
		this.head.yRot = (float) Math.toRadians(state.yRot);

		float pos = state.walkAnimationPos * 0.9f;
		float amp = Math.min(state.walkAnimationSpeed * 2.0f, 1.0f);
		this.frontLeft.xRot = (float) Math.cos(pos) * 1.1f * amp;
		this.backRight.xRot = (float) Math.cos(pos) * 1.1f * amp;
		this.frontRight.xRot = (float) Math.cos(pos + Math.PI) * 1.1f * amp;
		this.backLeft.xRot = (float) Math.cos(pos + Math.PI) * 1.1f * amp;

		float idle = (float) Math.sin(state.ageInTicks * 0.06f) * 0.05f;
		this.tail1.yRot = (float) Math.sin(pos) * 0.30f * amp + idle;
		this.tail2.yRot = (float) Math.sin(pos - 1.0f) * 0.40f * amp + idle;
	}
}
