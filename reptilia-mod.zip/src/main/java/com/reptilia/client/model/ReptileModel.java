package com.reptilia.client.model;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;

/** Un único modelo animado para los 10 reptiles: serpientes (segmentos que ondulan) y cuadrúpedos (patas + cola). */
public class ReptileModel extends EntityModel<ReptileRenderState> {
	private final boolean snake;
	private final float sway;
	private final ModelPart head;
	private final ModelPart hood;
	private final List<ModelPart> segments = new ArrayList<>();
	private final ModelPart[] legs = new ModelPart[4];
	private final List<ModelPart> tail = new ArrayList<>();

	public ReptileModel(ModelPart root, boolean snake, float sway) {
		super(root);
		this.snake = snake;
		this.sway = sway;
		this.head = root.getChild("head");
		this.hood = root.hasChild("hood") ? root.getChild("hood") : null;
		if (snake) {
			for (int i = 0; root.hasChild("seg" + i); i++) {
				this.segments.add(root.getChild("seg" + i));
			}
		} else {
			this.legs[0] = root.getChild("leg_fl");
			this.legs[1] = root.getChild("leg_fr");
			this.legs[2] = root.getChild("leg_bl");
			this.legs[3] = root.getChild("leg_br");
			ModelPart current = root;
			for (int i = 0; current.hasChild("tail" + i); i++) {
				current = current.getChild("tail" + i);
				this.tail.add(current);
			}
		}
	}

	@Override
	public void setupAnim(ReptileRenderState state) {
		super.setupAnim(state);
		float lookX = (float) Math.toRadians(state.xRot);
		float lookY = (float) Math.toRadians(state.yRot);
		float speed = Math.min(state.walkAnimationSpeed * 3.0f, 1.0f);

		if (this.snake) {
			float t = state.ageInTicks * (0.10f + 0.22f * speed);
			float amp = this.sway * (0.30f + 0.70f * speed);
			for (int i = 0; i < this.segments.size(); i++) {
				float phase = t - i * 0.55f;
				ModelPart seg = this.segments.get(i);
				seg.x = (float) Math.sin(phase) * amp;
				seg.yRot = (float) Math.cos(phase) * 0.22f;
			}
			this.head.x = (float) Math.sin(t + 0.55f) * amp;
			this.head.xRot = Math.max(-0.5f, Math.min(0.5f, lookX));
			this.head.yRot = Math.max(-0.7f, Math.min(0.7f, lookY)) + (float) Math.cos(t + 0.55f) * 0.22f;
			if (this.hood != null && !this.segments.isEmpty()) {
				this.hood.x = this.segments.get(0).x;
			}
		} else {
			this.head.xRot = Math.max(-0.5f, Math.min(0.5f, lookX));
			this.head.yRot = Math.max(-0.8f, Math.min(0.8f, lookY));
			float pos = state.walkAnimationPos * 0.9f;
			float amp = speed;
			this.legs[0].xRot = (float) Math.cos(pos) * 1.0f * amp;
			this.legs[3].xRot = (float) Math.cos(pos) * 1.0f * amp;
			this.legs[1].xRot = (float) Math.cos(pos + Math.PI) * 1.0f * amp;
			this.legs[2].xRot = (float) Math.cos(pos + Math.PI) * 1.0f * amp;
			float idle = (float) Math.sin(state.ageInTicks * 0.06f) * 0.05f;
			for (int i = 0; i < this.tail.size(); i++) {
				this.tail.get(i).yRot = (float) Math.sin(pos - i * 0.8f) * 0.30f * amp + idle;
			}
		}
	}
}
