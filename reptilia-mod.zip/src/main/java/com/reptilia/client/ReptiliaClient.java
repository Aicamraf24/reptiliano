package com.reptilia.client;

import com.reptilia.Reptilia;
import com.reptilia.client.model.ReptileLayers;
import com.reptilia.client.model.ReptileModel;
import com.reptilia.client.renderer.ReptileRenderer;
import com.reptilia.entity.ModEntityTypes;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public class ReptiliaClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		for (ReptileLayers.Info info : ReptileLayers.ALL) {
			String name = info.name();
			ModelLayerLocation loc = new ModelLayerLocation(Reptilia.id(name), "main");
			ModelLayerRegistry.registerModelLayer(loc, () -> ReptileLayers.create(name));
			Identifier texture = Reptilia.id("textures/entity/" + name + ".png");
			EntityRendererRegistry.register(ModEntityTypes.ALL.get(name),
					ctx -> new ReptileRenderer(ctx, new ReptileModel(ctx.bakeLayer(loc), info.snake(), info.sway()),
							texture, info.shadow()));
		}
	}
}
