package com.reptilia.client;

import com.reptilia.Reptilia;
import com.reptilia.client.model.LizardModel;
import com.reptilia.client.model.ReptileShapes;
import com.reptilia.client.model.SnakeModel;
import com.reptilia.client.renderer.ReptileRenderer;
import com.reptilia.entity.ModEntityTypes;
import com.reptilia.entity.ReptileEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;

public class ReptiliaClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		lizard("nile_crocodile", ModEntityTypes.NILE_CROCODILE, ReptileShapes.NILE_CROCODILE, 0.7f);
		lizard("alligator", ModEntityTypes.ALLIGATOR, ReptileShapes.ALLIGATOR, 0.65f);
		lizard("caiman", ModEntityTypes.CAIMAN, ReptileShapes.CAIMAN, 0.45f);
		lizard("iguana", ModEntityTypes.IGUANA, ReptileShapes.IGUANA, 0.3f);
		lizard("gecko", ModEntityTypes.GECKO, ReptileShapes.GECKO, 0.12f);

		snake("titanoboa", ModEntityTypes.TITANOBOA, ReptileShapes.TITANOBOA, 1.2f);
		snake("anaconda", ModEntityTypes.ANACONDA, ReptileShapes.ANACONDA, 0.6f);
		snake("king_cobra", ModEntityTypes.KING_COBRA, ReptileShapes.KING_COBRA, 0.4f);
		snake("rattlesnake", ModEntityTypes.RATTLESNAKE, ReptileShapes.RATTLESNAKE, 0.35f);
		snake("black_mamba", ModEntityTypes.BLACK_MAMBA, ReptileShapes.BLACK_MAMBA, 0.35f);
	}

	private static ModelLayerLocation layer(String name) {
		return new ModelLayerLocation(Reptilia.id(name), "main");
	}

	private static Identifier texture(String name) {
		return Reptilia.id("textures/entity/" + name + ".png");
	}

	private static void lizard(String name, EntityType<ReptileEntity> type, ReptileShapes.Lizard shape, float shadow) {
		ModelLayerLocation loc = layer(name);
		ModelLayerRegistry.registerModelLayer(loc, () -> LizardModel.create(shape));
		EntityRendererRegistry.register(type,
				ctx -> new ReptileRenderer(ctx, new LizardModel(ctx.bakeLayer(loc)), texture(name), shadow));
	}

	private static void snake(String name, EntityType<ReptileEntity> type, ReptileShapes.Snake shape, float shadow) {
		ModelLayerLocation loc = layer(name);
		ModelLayerRegistry.registerModelLayer(loc, () -> SnakeModel.create(shape));
		EntityRendererRegistry.register(type,
				ctx -> new ReptileRenderer(ctx, new SnakeModel(ctx.bakeLayer(loc), shape.segCount()), texture(name), shadow));
	}
}
