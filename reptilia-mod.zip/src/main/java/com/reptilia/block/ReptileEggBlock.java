package com.reptilia.block;

import com.reptilia.entity.ModEntityTypes;
import com.reptilia.entity.ReptileEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Huevo fértil. Avanza 10 etapas; sobre una superficie cálida (bloque de magma, hoguera) cada etapa dura 30 s
 * (5 minutos en total) y sobre cualquier otro bloque 3 min (30 minutos en total). Al terminar nace una cría.
 */
public class ReptileEggBlock extends Block {
	public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 9);
	private static final VoxelShape SHAPE = Block.box(4.0, 0.0, 4.0, 12.0, 10.0, 12.0);
	private static final int WARM_TICKS = 600;    // 10 etapas x 30 s = 5 min
	private static final int COLD_TICKS = 3600;   // 10 etapas x 3 min = 30 min

	private final String species;

	public ReptileEggBlock(String species, BlockBehaviour.Properties properties) {
		super(properties);
		this.species = species;
		this.registerDefaultState(this.stateDefinition.any().setValue(STAGE, 0));
	}

	@Override
	public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(STAGE);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return SHAPE;
	}

	@Override
	public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
		if (level instanceof ServerLevel server) {
			server.scheduleTick(pos, this, delay(server, pos));
		}
	}

	private static int delay(ServerLevel level, BlockPos pos) {
		BlockState below = level.getBlockState(pos.below());
		boolean warm = below.is(Blocks.MAGMA_BLOCK) || below.is(BlockTags.CAMPFIRES);
		return warm ? WARM_TICKS : COLD_TICKS;
	}

	@Override
	public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		int stage = state.getValue(STAGE);
		if (stage >= 9) {
			hatch(level, pos);
			return;
		}
		level.setBlock(pos, state.setValue(STAGE, stage + 1), 2);
		level.scheduleTick(pos, this, delay(level, pos));
	}

	private void hatch(ServerLevel level, BlockPos pos) {
		level.removeBlock(pos, false);
		EntityType<ReptileEntity> type = ModEntityTypes.ALL.get(this.species);
		if (type == null) {
			return;
		}
		ReptileEntity baby = type.create(level, EntitySpawnReason.BREEDING);
		if (baby == null) {
			return;
		}
		baby.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
		AttributeInstance scale = baby.getAttribute(Attributes.SCALE);
		if (scale != null) {
			scale.setBaseValue(ReptileEntity.BABY_SCALE);
		}
		level.addFreshEntity(baby);
		level.playSound(null, pos, SoundEvents.TURTLE_EGG_HATCH, SoundSource.BLOCKS, 0.8f, 0.9f);
	}
}
