package com.reptilia.block;

import com.reptilia.Reptilia;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.TintedParticleLeavesBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.grower.TreeGrower;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;

/** Madera de ceiba: el árbol gigante de la Ciénaga Reptil. */
public final class ModBlocks {
	/** Orden en el que aparecen en la pestaña creativa. */
	public static final List<Block> ALL = new ArrayList<>();

	public static final ResourceKey<ConfiguredFeature<?, ?>> CEIBA_TREE_KEY =
			ResourceKey.create(Registries.CONFIGURED_FEATURE, Reptilia.id("ceiba_tree"));
	public static final TreeGrower CEIBA_GROWER =
			new TreeGrower("ceiba", Optional.empty(), Optional.of(CEIBA_TREE_KEY), Optional.empty());

	public static final Block CEIBA_LOG = block("ceiba_log", RotatedPillarBlock::new, Blocks.OAK_LOG, false);
	public static final Block STRIPPED_CEIBA_LOG = block("stripped_ceiba_log", RotatedPillarBlock::new, Blocks.OAK_LOG, false);
	public static final Block CEIBA_WOOD = block("ceiba_wood", RotatedPillarBlock::new, Blocks.OAK_WOOD, false);
	public static final Block STRIPPED_CEIBA_WOOD = block("stripped_ceiba_wood", RotatedPillarBlock::new, Blocks.OAK_WOOD, false);
	public static final Block CEIBA_PLANKS = block("ceiba_planks", Block::new, Blocks.OAK_PLANKS, false);
	public static final Block CEIBA_STAIRS = block("ceiba_stairs",
			p -> new StairBlock(CEIBA_PLANKS.defaultBlockState(), p), Blocks.OAK_PLANKS, false);
	public static final Block CEIBA_SLAB = block("ceiba_slab", SlabBlock::new, Blocks.OAK_PLANKS, false);
	public static final Block CEIBA_FENCE = block("ceiba_fence", FenceBlock::new, Blocks.OAK_FENCE, false);
	public static final Block CEIBA_FENCE_GATE = block("ceiba_fence_gate",
			p -> new FenceGateBlock(WoodType.OAK, p), Blocks.OAK_FENCE_GATE, false);
	public static final Block CEIBA_DOOR = block("ceiba_door",
			p -> new DoorBlock(BlockSetType.OAK, p), Blocks.OAK_DOOR, true);
	public static final Block CEIBA_TRAPDOOR = block("ceiba_trapdoor",
			p -> new TrapDoorBlock(BlockSetType.OAK, p), Blocks.OAK_TRAPDOOR, false);
	public static final Block CEIBA_BUTTON = block("ceiba_button",
			p -> new ButtonBlock(BlockSetType.OAK, 30, p), Blocks.OAK_BUTTON, false);
	public static final Block CEIBA_PRESSURE_PLATE = block("ceiba_pressure_plate",
			p -> new PressurePlateBlock(BlockSetType.OAK, p), Blocks.OAK_PRESSURE_PLATE, false);
	public static final Block CEIBA_LEAVES = block("ceiba_leaves",
			p -> new TintedParticleLeavesBlock(0.01F, p), Blocks.OAK_LEAVES, false);
	public static final Block CEIBA_SAPLING = block("ceiba_sapling",
			p -> new SaplingBlock(CEIBA_GROWER, p), Blocks.OAK_SAPLING, false);

	private static <T extends Block> T block(String name, Function<BlockBehaviour.Properties, T> factory,
			Block copyFrom, boolean tall) {
		ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Reptilia.id(name));
		T block = factory.apply(BlockBehaviour.Properties.ofFullCopy(copyFrom).setId(key));
		Registry.register(BuiltInRegistries.BLOCK, key, block);

		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, Reptilia.id(name));
		Item.Properties props = new Item.Properties().setId(itemKey).useBlockDescriptionPrefix();
		Item item = tall ? new DoubleHighBlockItem(block, props) : new BlockItem(block, props);
		Registry.register(BuiltInRegistries.ITEM, itemKey, item);

		ALL.add(block);
		return block;
	}

	public static void initialize() {
		// Con el hacha el tronco se descorteza
		StrippableBlockRegistry.register(CEIBA_LOG, STRIPPED_CEIBA_LOG);
		StrippableBlockRegistry.register(CEIBA_WOOD, STRIPPED_CEIBA_WOOD);
	}
}
