package com.reptilia.mixin;

import com.mojang.datafixers.util.Pair;
import com.reptilia.world.ModWorldgen;
import java.util.function.Consumer;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.OverworldBiomeBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Cambia la mitad (aprox.) de las zonas climaticas del pantano por la Cienaga Reptil
 * cuando el juego construye la tabla de biomas del Overworld.
 */
@Mixin(OverworldBiomeBuilder.class)
public abstract class OverworldBiomeBuilderMixin {
	@ModifyVariable(method = "addBiomes", at = @At("HEAD"), argsOnly = true, index = 1, require = 0)
	private Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> reptilia$replaceSwamp(
			Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> original) {
		return pair -> {
			if (Biomes.SWAMP.equals(pair.getSecond()) && (pair.getFirst().toString().hashCode() & 1) == 0) {
				original.accept(Pair.of(pair.getFirst(), ModWorldgen.REPTILE_SWAMP));
			} else {
				original.accept(pair);
			}
		};
	}
}
