package com.reptilia.mixin;

import com.reptilia.world.ReptileFlora;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Al terminar la decoracion normal de un chunk, añade la flora de la Cienaga Reptil. */
@Mixin(ChunkGenerator.class)
public abstract class ChunkGeneratorMixin {
	@Inject(method = "applyBiomeDecoration", at = @At("TAIL"), require = 0)
	private void reptilia$flora(WorldGenLevel level, ChunkAccess chunk, StructureManager structures, CallbackInfo ci) {
		ReptileFlora.decorate(level, chunk);
	}
}
