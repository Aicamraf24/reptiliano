package com.reptilia;

import com.reptilia.block.ModBlocks;
import com.reptilia.entity.ModEntityTypes;
import com.reptilia.item.ModItems;
import com.reptilia.world.ModWorldgen;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Reptilia implements ModInitializer {
	public static final String MOD_ID = "reptilia";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.initialize();      // madera de ceiba (bloques + items de bloque)
		ModEntityTypes.initialize(); // 10 reptiles
		ModItems.initialize();       // escamas, carnes, armaduras, huevos, pestaña creativa
		ModWorldgen.initialize();    // bioma + spawns + corteza
		LOGGER.info("Reptilia cargado");
	}
}
