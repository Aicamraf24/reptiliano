package com.reptilia.item;

import com.reptilia.Reptilia;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModArmorMaterials {
	// Durabilidad base: cuero 5, hierro 15, diamante 33
	public static final int SNAKE_DURABILITY = 6;
	public static final int CROCODILE_DURABILITY = 15;
	public static final int TITANOBOA_DURABILITY = 25;

	private static ResourceKey<EquipmentAsset> asset(String name) {
		return ResourceKey.create(EquipmentAssets.ROOT_ID, Reptilia.id(name));
	}

	private static TagKey<Item> repairs(String name) {
		return TagKey.create(Registries.ITEM, Reptilia.id(name));
	}

	/** Como el cuero pero protege un poco menos: 1/2/2/1 (cuero: 1/3/2/1). */
	public static final ArmorMaterial SNAKE_SCALE = new ArmorMaterial(
			SNAKE_DURABILITY,
			Map.of(ArmorType.HELMET, 1, ArmorType.CHESTPLATE, 2, ArmorType.LEGGINGS, 2, ArmorType.BOOTS, 1),
			12, SoundEvents.ARMOR_EQUIP_LEATHER, 0.0F, 0.0F,
			repairs("repairs_snake_scale_armor"), asset("snake_scale"));

	/** Mismo nivel que el hierro: 2/6/5/2. */
	public static final ArmorMaterial CROCODILE_SCALE = new ArmorMaterial(
			CROCODILE_DURABILITY,
			Map.of(ArmorType.HELMET, 2, ArmorType.CHESTPLATE, 6, ArmorType.LEGGINGS, 5, ArmorType.BOOTS, 2),
			9, SoundEvents.ARMOR_EQUIP_IRON, 0.0F, 0.0F,
			repairs("repairs_crocodile_scale_armor"), asset("crocodile_scale"));

	/** Entre hierro (15 de defensa) y diamante (20): 3/7/6/2 = 18, con algo de dureza. */
	public static final ArmorMaterial TITANOBOA_SCALE = new ArmorMaterial(
			TITANOBOA_DURABILITY,
			Map.of(ArmorType.HELMET, 3, ArmorType.CHESTPLATE, 7, ArmorType.LEGGINGS, 6, ArmorType.BOOTS, 2),
			12, SoundEvents.ARMOR_EQUIP_DIAMOND, 1.0F, 0.0F,
			repairs("repairs_titanoboa_scale_armor"), asset("titanoboa_scale"));

	private ModArmorMaterials() {}
}
