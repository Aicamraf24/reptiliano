package com.reptilia.item;

import com.reptilia.Reptilia;
import com.reptilia.block.ModBlocks;
import com.reptilia.entity.ModEntityTypes;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

public class ModItems {
	// ---- Materiales ----
	public static final Item SNAKE_SCALE = register("snake_scale", Item::new, new Item.Properties());
	public static final Item CROCODILE_SCALE = register("crocodile_scale", Item::new, new Item.Properties());
	public static final Item TITANOBOA_SCALE = register("titanoboa_scale", Item::new, new Item.Properties().rarity(net.minecraft.world.item.Rarity.RARE));
	public static final Item GECKO_SLIME = register("gecko_slime", Item::new, new Item.Properties());

	// ---- Carnes (crudas y cocinadas) ----
	public static final Item SNAKE_MEAT = register("snake_meat", Item::new, food(2, 0.3f));
	public static final Item COOKED_SNAKE_MEAT = register("cooked_snake_meat", Item::new, food(6, 0.8f));
	public static final Item CROCODILE_MEAT = register("crocodile_meat", Item::new, food(3, 0.3f));
	public static final Item COOKED_CROCODILE_MEAT = register("cooked_crocodile_meat", Item::new, food(8, 0.8f));
	public static final Item IGUANA_MEAT = register("iguana_meat", Item::new, food(2, 0.3f));
	public static final Item COOKED_IGUANA_MEAT = register("cooked_iguana_meat", Item::new, food(6, 0.8f));
	public static final Item GECKO_MEAT = register("gecko_meat", Item::new, food(1, 0.2f));
	public static final Item COOKED_GECKO_MEAT = register("cooked_gecko_meat", Item::new, food(4, 0.6f));

	// ---- Armaduras ----
	public static final Item SNAKE_SCALE_HELMET = armor("snake_scale_helmet", ModArmorMaterials.SNAKE_SCALE, ArmorType.HELMET, ModArmorMaterials.SNAKE_DURABILITY);
	public static final Item SNAKE_SCALE_CHESTPLATE = armor("snake_scale_chestplate", ModArmorMaterials.SNAKE_SCALE, ArmorType.CHESTPLATE, ModArmorMaterials.SNAKE_DURABILITY);
	public static final Item SNAKE_SCALE_LEGGINGS = armor("snake_scale_leggings", ModArmorMaterials.SNAKE_SCALE, ArmorType.LEGGINGS, ModArmorMaterials.SNAKE_DURABILITY);
	public static final Item SNAKE_SCALE_BOOTS = armor("snake_scale_boots", ModArmorMaterials.SNAKE_SCALE, ArmorType.BOOTS, ModArmorMaterials.SNAKE_DURABILITY);

	public static final Item CROCODILE_SCALE_HELMET = armor("crocodile_scale_helmet", ModArmorMaterials.CROCODILE_SCALE, ArmorType.HELMET, ModArmorMaterials.CROCODILE_DURABILITY);
	public static final Item CROCODILE_SCALE_CHESTPLATE = armor("crocodile_scale_chestplate", ModArmorMaterials.CROCODILE_SCALE, ArmorType.CHESTPLATE, ModArmorMaterials.CROCODILE_DURABILITY);
	public static final Item CROCODILE_SCALE_LEGGINGS = armor("crocodile_scale_leggings", ModArmorMaterials.CROCODILE_SCALE, ArmorType.LEGGINGS, ModArmorMaterials.CROCODILE_DURABILITY);
	public static final Item CROCODILE_SCALE_BOOTS = armor("crocodile_scale_boots", ModArmorMaterials.CROCODILE_SCALE, ArmorType.BOOTS, ModArmorMaterials.CROCODILE_DURABILITY);

	public static final Item TITANOBOA_SCALE_HELMET = armor("titanoboa_scale_helmet", ModArmorMaterials.TITANOBOA_SCALE, ArmorType.HELMET, ModArmorMaterials.TITANOBOA_DURABILITY);
	public static final Item TITANOBOA_SCALE_CHESTPLATE = armor("titanoboa_scale_chestplate", ModArmorMaterials.TITANOBOA_SCALE, ArmorType.CHESTPLATE, ModArmorMaterials.TITANOBOA_DURABILITY);
	public static final Item TITANOBOA_SCALE_LEGGINGS = armor("titanoboa_scale_leggings", ModArmorMaterials.TITANOBOA_SCALE, ArmorType.LEGGINGS, ModArmorMaterials.TITANOBOA_DURABILITY);
	public static final Item TITANOBOA_SCALE_BOOTS = armor("titanoboa_scale_boots", ModArmorMaterials.TITANOBOA_SCALE, ArmorType.BOOTS, ModArmorMaterials.TITANOBOA_DURABILITY);

	// ---- Spawn eggs (uno por animal) ----
	public static final Item TITANOBOA_SPAWN_EGG = egg(ModEntityTypes.TITANOBOA);
	public static final Item ANACONDA_SPAWN_EGG = egg(ModEntityTypes.ANACONDA);
	public static final Item KING_COBRA_SPAWN_EGG = egg(ModEntityTypes.KING_COBRA);
	public static final Item RATTLESNAKE_SPAWN_EGG = egg(ModEntityTypes.RATTLESNAKE);
	public static final Item BLACK_MAMBA_SPAWN_EGG = egg(ModEntityTypes.BLACK_MAMBA);
	public static final Item NILE_CROCODILE_SPAWN_EGG = egg(ModEntityTypes.NILE_CROCODILE);
	public static final Item CAIMAN_SPAWN_EGG = egg(ModEntityTypes.CAIMAN);
	public static final Item ALLIGATOR_SPAWN_EGG = egg(ModEntityTypes.ALLIGATOR);
	public static final Item IGUANA_SPAWN_EGG = egg(ModEntityTypes.IGUANA);
	public static final Item GECKO_SPAWN_EGG = egg(ModEntityTypes.GECKO);

	// ---- Pestaña propia del creativo ----
	public static final ResourceKey<CreativeModeTab> REPTILES_TAB_KEY =
			ResourceKey.create(Registries.CREATIVE_MODE_TAB, Reptilia.id("reptiles"));

	public static final CreativeModeTab REPTILES_TAB = FabricCreativeModeTab.builder()
			.icon(() -> new ItemStack(TITANOBOA_SCALE))
			.title(Component.translatable("itemGroup.reptilia.reptiles"))
			.displayItems((params, output) -> {
				// Spawn eggs
				output.accept(TITANOBOA_SPAWN_EGG);
				output.accept(ANACONDA_SPAWN_EGG);
				output.accept(KING_COBRA_SPAWN_EGG);
				output.accept(RATTLESNAKE_SPAWN_EGG);
				output.accept(BLACK_MAMBA_SPAWN_EGG);
				output.accept(NILE_CROCODILE_SPAWN_EGG);
				output.accept(CAIMAN_SPAWN_EGG);
				output.accept(ALLIGATOR_SPAWN_EGG);
				output.accept(IGUANA_SPAWN_EGG);
				output.accept(GECKO_SPAWN_EGG);
				// Materiales y comida
				output.accept(SNAKE_SCALE);
				output.accept(CROCODILE_SCALE);
				output.accept(TITANOBOA_SCALE);
				output.accept(GECKO_SLIME);
				output.accept(SNAKE_MEAT);
				output.accept(COOKED_SNAKE_MEAT);
				output.accept(CROCODILE_MEAT);
				output.accept(COOKED_CROCODILE_MEAT);
				output.accept(IGUANA_MEAT);
				output.accept(COOKED_IGUANA_MEAT);
				output.accept(GECKO_MEAT);
				output.accept(COOKED_GECKO_MEAT);
				// Armaduras
				output.accept(SNAKE_SCALE_HELMET);
				output.accept(SNAKE_SCALE_CHESTPLATE);
				output.accept(SNAKE_SCALE_LEGGINGS);
				output.accept(SNAKE_SCALE_BOOTS);
				output.accept(CROCODILE_SCALE_HELMET);
				output.accept(CROCODILE_SCALE_CHESTPLATE);
				output.accept(CROCODILE_SCALE_LEGGINGS);
				output.accept(CROCODILE_SCALE_BOOTS);
				output.accept(TITANOBOA_SCALE_HELMET);
				output.accept(TITANOBOA_SCALE_CHESTPLATE);
				output.accept(TITANOBOA_SCALE_LEGGINGS);
				output.accept(TITANOBOA_SCALE_BOOTS);
				// Madera de ceiba
				ModBlocks.ALL.forEach(output::accept);
			})
			.build();

	private static Item.Properties food(int nutrition, float saturation) {
		return new Item.Properties().food(new FoodProperties.Builder()
				.nutrition(nutrition).saturationModifier(saturation).build());
	}

	private static Item armor(String name, ArmorMaterial material, ArmorType type, int baseDurability) {
		return register(name, Item::new, new Item.Properties()
				.humanoidArmor(material, type)
				.durability(type.getDurability(baseDurability)));
	}

	private static Item egg(EntityType<?> type) {
		String name = BuiltInRegistries.ENTITY_TYPE.getKey(type).getPath() + "_spawn_egg";
		return register(name, SpawnEggItem::new, new Item.Properties().spawnEgg(type));
	}

	public static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties properties) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Reptilia.id(name));
		Item item = factory.apply(properties.setId(key));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}

	public static void initialize() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, REPTILES_TAB_KEY, REPTILES_TAB);
	}
}
