package com.reptilia.entity;

import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;

/** Datos de cada reptil: hitbox, vida, daño, comportamiento y efectos al golpear. */
public record ReptileSpec(
		String id,
		float width, float height,
		double health, double damage, double speed,
		Behavior behavior,
		Holder<MobEffect> effect1, int ticks1, int amp1,
		Holder<MobEffect> effect2, int ticks2, int amp2,
		double armor, double knockbackResistance) {

	public enum Behavior { PASSIVE, NEUTRAL, AGGRESSIVE }
}
