package com.reptilia.entity;

import com.reptilia.Reptilia;
import com.reptilia.entity.ReptileSpec.Behavior;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class ModEntityTypes {
	/** Tipo -> datos. Debe declararse antes que los tipos. */
	public static final Map<EntityType<?>, ReptileSpec> SPECS = new HashMap<>();
	/** Todos los reptiles en orden (para items, renderers, etc.). */
	public static final Map<String, EntityType<ReptileEntity>> ALL = new LinkedHashMap<>();

	// ---- Serpientes (hitbox ancha y baja: el cuerpo largo lo da el modelo) ----
	public static final EntityType<ReptileEntity> TITANOBOA = register(new ReptileSpec("titanoboa", 3.5f, 1.2f,
			200, 12, 0.30, Behavior.AGGRESSIVE,
			MobEffects.SLOWNESS, 160, 1, MobEffects.WEAKNESS, 160, 0, 6.0, 0.7));
	public static final EntityType<ReptileEntity> ANACONDA = register(new ReptileSpec("anaconda", 2.4f, 0.8f,
			40, 6, 0.26, Behavior.NEUTRAL,
			MobEffects.SLOWNESS, 100, 0, MobEffects.WEAKNESS, 100, 0, 2.0, 0.2));
	public static final EntityType<ReptileEntity> KING_COBRA = register(new ReptileSpec("king_cobra", 1.2f, 0.8f,
			24, 5, 0.28, Behavior.NEUTRAL,
			MobEffects.POISON, 200, 0, null, 0, 0, 0.0, 0.0));
	public static final EntityType<ReptileEntity> RATTLESNAKE = register(new ReptileSpec("rattlesnake", 0.9f, 0.4f,
			14, 3, 0.25, Behavior.NEUTRAL,
			MobEffects.POISON, 160, 0, null, 0, 0, 0.0, 0.0));
	public static final EntityType<ReptileEntity> BLACK_MAMBA = register(new ReptileSpec("black_mamba", 1.0f, 0.4f,
			20, 5, 0.38, Behavior.NEUTRAL,
			MobEffects.POISON, 200, 1, null, 0, 0, 0.0, 0.0));

	// ---- Cocodrilos ----
	public static final EntityType<ReptileEntity> NILE_CROCODILE = register(new ReptileSpec("nile_crocodile", 1.7f, 0.8f,
			40, 9, 0.24, Behavior.AGGRESSIVE,
			null, 0, 0, null, 0, 0, 4.0, 0.3));
	public static final EntityType<ReptileEntity> CAIMAN = register(new ReptileSpec("caiman", 1.2f, 0.6f,
			28, 6, 0.25, Behavior.NEUTRAL,
			null, 0, 0, null, 0, 0, 3.0, 0.1));
	public static final EntityType<ReptileEntity> ALLIGATOR = register(new ReptileSpec("alligator", 1.6f, 0.7f,
			34, 8, 0.24, Behavior.AGGRESSIVE,
			null, 0, 0, null, 0, 0, 4.0, 0.2));

	// ---- Lagartos ----
	public static final EntityType<ReptileEntity> IGUANA = register(new ReptileSpec("iguana", 0.7f, 0.55f,
			10, 0, 0.26, Behavior.PASSIVE,
			null, 0, 0, null, 0, 0, 0.0, 0.0));
	public static final EntityType<ReptileEntity> GECKO = register(new ReptileSpec("gecko", 0.35f, 0.25f,
			4, 0, 0.28, Behavior.PASSIVE,
			null, 0, 0, null, 0, 0, 0.0, 0.0));

	private static EntityType<ReptileEntity> register(ReptileSpec spec) {
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, Reptilia.id(spec.id()));
		EntityType<ReptileEntity> type = EntityType.Builder.<ReptileEntity>of(ReptileEntity::new, MobCategory.CREATURE)
				.sized(spec.width(), spec.height())
				.build(key);
		Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
		SPECS.put(type, spec);
		ALL.put(spec.id(), type);
		FabricDefaultAttributeRegistry.register(type, ReptileEntity.createAttributes(spec));
		return type;
	}

	public static void initialize() {
		Reptilia.LOGGER.info("Registrando {} reptiles", ALL.size());
	}
}
