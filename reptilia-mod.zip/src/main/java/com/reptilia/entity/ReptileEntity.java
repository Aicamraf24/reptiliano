package com.reptilia.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Entidad única para todos los reptiles; cada tipo trae su propio ReptileSpec. */
public class ReptileEntity extends PathfinderMob {
	public ReptileEntity(EntityType<? extends ReptileEntity> type, Level level) {
		super(type, level);
	}

	/** Como los animales: no desaparecen al alejarte (también necesario para soltarlos con la cápsula). */
	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	/** registerGoals() se llama desde el constructor padre, por eso el spec se busca por tipo y no en un campo. */
	private ReptileSpec spec() {
		return ModEntityTypes.SPECS.get(this.getType());
	}

	public static AttributeSupplier.Builder createAttributes(ReptileSpec s) {
		return PathfinderMob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, s.health())
				.add(Attributes.MOVEMENT_SPEED, s.speed())
				.add(Attributes.ATTACK_DAMAGE, s.damage())
				.add(Attributes.FOLLOW_RANGE, 24.0)
				.add(Attributes.ARMOR, s.armor())
				.add(Attributes.KNOCKBACK_RESISTANCE, s.knockbackResistance());
	}

	@Override
	protected void registerGoals() {
		ReptileSpec s = spec();
		this.goalSelector.addGoal(0, new FloatGoal(this));
		if (s.behavior() == ReptileSpec.Behavior.PASSIVE) {
			this.goalSelector.addGoal(1, new PanicGoal(this, 1.5));
		} else {
			this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
			this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
			if (s.behavior() == ReptileSpec.Behavior.AGGRESSIVE) {
				this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
			}
		}
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
	}

	/** Al golpear aplica veneno (cobra, cascabel, mamba) o lentitud + debilidad (constrictoras). */
	@Override
	public boolean doHurtTarget(ServerLevel level, Entity target) {
		boolean hit = super.doHurtTarget(level, target);
		if (hit && target instanceof LivingEntity living) {
			ReptileSpec s = spec();
			if (s.effect1() != null) {
				living.addEffect(new MobEffectInstance(s.effect1(), s.ticks1(), s.amp1()), this);
			}
			if (s.effect2() != null) {
				living.addEffect(new MobEffectInstance(s.effect2(), s.ticks2(), s.amp2()), this);
			}
		}
		return hit;
	}
}
