package com.reptilia.entity;

import com.reptilia.block.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Entidad única para todos los reptiles; cada tipo trae su propio ReptileSpec. */
public class ReptileEntity extends PathfinderMob {
	public ReptileEntity(EntityType<? extends ReptileEntity> type, Level level) {
		super(type, level);
	}

	/** Como los animales: no desaparecen al alejarte (también necesario para soltarlos con la cápsula). */
	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}


	/** Escala de una cría recién nacida (crece sola hasta 1.0 en unos 10 minutos). */
	public static final float BABY_SCALE = 0.5f;
	private static final int LAY_DELAY = 100;        // 5 s despues de darle carne
	private static final int BREED_COOLDOWN = 6000;  // 5 min entre huevos

	private int layTimer = -1;
	private int breedCooldown = 0;

	private boolean isAdult() {
		AttributeInstance scale = this.getAttribute(Attributes.SCALE);
		return scale == null || scale.getBaseValue() >= 0.99;
	}

	/** Carne cruda de vaca o cerdo: el animal adulto pone un huevo fértil poco después. */
	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if ((stack.is(Items.BEEF) || stack.is(Items.PORKCHOP)) && isAdult()
				&& this.layTimer < 0 && this.breedCooldown <= 0) {
			if (this.level() instanceof ServerLevel server) {
				stack.consume(1, player);
				this.layTimer = LAY_DELAY;
				server.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + this.getBbHeight() + 0.2,
						this.getZ(), 6, 0.3, 0.2, 0.3, 0.02);
			}
			return InteractionResult.SUCCESS;
		}
		return super.mobInteract(player, hand);
	}


	/** Inmunes al daño del bloque de magma (y de suelos calientes en general). */
	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		if (source.is(DamageTypes.HOT_FLOOR)) {
			return false;
		}
		return super.hurtServer(level, source, amount);
	}

	/** Las crías no sueltan nada al morir (ni objetos ni experiencia). */
	@Override
	protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {
		if (!isAdult()) {
			return;
		}
		super.dropAllDeathLoot(level, source);
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level() instanceof ServerLevel server) {
			if (this.breedCooldown > 0) {
				this.breedCooldown--;
			}
			if (this.layTimer > 0 && --this.layTimer == 0) {
				layEgg(server);
				this.layTimer = -1;
				this.breedCooldown = BREED_COOLDOWN;
			}
			if (this.tickCount % 200 == 0) {
				AttributeInstance scale = this.getAttribute(Attributes.SCALE);
				if (scale != null && scale.getBaseValue() < 1.0) {
					scale.setBaseValue(Math.min(1.0, scale.getBaseValue() + 0.0083));
				}
			}
		}
	}

	private void layEgg(ServerLevel server) {
		Block egg = ModBlocks.EGGS.get(spec().id());
		if (egg == null) {
			return;
		}
		BlockPos origin = this.blockPosition();
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				BlockPos pos = origin.offset(dx, 0, dz);
				BlockPos below = pos.below();
				BlockState belowState = server.getBlockState(below);
				if (server.getBlockState(pos).isAir() && belowState.isFaceSturdy(server, below, Direction.UP)) {
					server.setBlock(pos, egg.defaultBlockState(), 3);
					return;
				}
			}
		}
	}

	/** registerGoals() se llama desde el constructor padre, por eso el spec se busca por tipo y no en un campo. */
	private ReptileSpec spec() {
		return ModEntityTypes.SPECS.get(this.getType());
	}

	public static AttributeSupplier.Builder createAttributes(ReptileSpec s) {
		return PathfinderMob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, s.health())
				.add(Attributes.MOVEMENT_SPEED, s.speed())
				.add(Attributes.ATTACK_DAMAGE, s.damage())
				.add(Attributes.FOLLOW_RANGE, 24.0)
				.add(Attributes.ARMOR, s.armor())
				.add(Attributes.KNOCKBACK_RESISTANCE, s.knockbackResistance());
	}

	@Override
	protected void registerGoals() {
		ReptileSpec s = spec();
		this.goalSelector.addGoal(0, new FloatGoal(this));
		if (s.behavior() == ReptileSpec.Behavior.PASSIVE) {
			this.goalSelector.addGoal(1, new PanicGoal(this, 1.5));
		} else {
			this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
			this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
			if (s.behavior() == ReptileSpec.Behavior.AGGRESSIVE) {
				this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
			}
		}
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
	}

	/** Al golpear aplica veneno (cobra, cascabel, mamba) o lentitud + debilidad (constrictoras). */
	@Override
	public boolean doHurtTarget(ServerLevel level, Entity target) {
		boolean hit = super.doHurtTarget(level, target);
		if (hit && target instanceof LivingEntity living) {
			ReptileSpec s = spec();
			if (s.effect1() != null) {
				living.addEffect(new MobEffectInstance(s.effect1(), s.ticks1(), s.amp1()), this);
			}
			if (s.effect2() != null) {
				living.addEffect(new MobEffectInstance(s.effect2(), s.ticks2(), s.amp2()), this);
			}
		}
		return hit;
	}
}
