package com.reptilia.world;

import com.mojang.serialization.Codec;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Feature propia: reparte la flora de la Cienaga Reptil por el chunk donde se ejecuta. */
public class ReptileFloraFeature extends Feature<NoneFeatureConfiguration> {
	public ReptileFloraFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		return ReptileFlora.decorate(context.level(), context.origin());
	}
}
