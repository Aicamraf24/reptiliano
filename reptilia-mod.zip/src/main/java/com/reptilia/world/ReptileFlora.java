package com.reptilia.world;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Flores, helechos e hierbas de la Ciénaga Reptil. Se colocan desde codigo (y protegidas con try/catch) en lugar de
 * archivos de datos, para que un fallo aqui nunca pueda impedir que el mundo se cree.
 */
public final class ReptileFlora {
	private record Plant(Block block, boolean tall) {}

	private static final List<Plant> FLOWERS = List.of(
			new Plant(Blocks.BLUE_ORCHID, false), new Plant(Blocks.BLUE_ORCHID, false),
			new Plant(Blocks.ALLIUM, false), new Plant(Blocks.AZURE_BLUET, false),
			new Plant(Blocks.PINK_TULIP, false), new Plant(Blocks.ORANGE_TULIP, false),
			new Plant(Blocks.RED_TULIP, false), new Plant(Blocks.CORNFLOWER, false),
			new Plant(Blocks.LILY_OF_THE_VALLEY, false));
	private static final List<Plant> TALL_FLOWERS = List.of(
			new Plant(Blocks.PEONY, true), new Plant(Blocks.LILAC, true), new Plant(Blocks.ROSE_BUSH, true));
	private static final List<Plant> FERNS = List.of(
			new Plant(Blocks.FERN, false), new Plant(Blocks.FERN, false), new Plant(Blocks.LARGE_FERN, true));
	private static final List<Plant> GRASS = List.of(
			new Plant(Blocks.SHORT_GRASS, false), new Plant(Blocks.SHORT_GRASS, false),
			new Plant(Blocks.TALL_GRASS, true));

	public static void decorate(WorldGenLevel level, ChunkAccess chunk) {
		try {
			ChunkPos chunkPos = chunk.getPos();
			int x0 = chunkPos.getMinBlockX();
			int z0 = chunkPos.getMinBlockZ();
			RandomSource random = RandomSource.create(x0 * 341873128712L + z0 * 132897987541L + 7919L);
			scatter(level, random, x0, z0, FLOWERS, 20);
			scatter(level, random, x0, z0, TALL_FLOWERS, 6);
			scatter(level, random, x0, z0, FERNS, 24);
			scatter(level, random, x0, z0, GRASS, 40);
		} catch (Throwable ignored) {
			// nunca romper la generacion del mundo por culpa de la decoracion
		}
	}

	private static void scatter(WorldGenLevel level, RandomSource random, int x0, int z0, List<Plant> pool, int attempts) {
		for (int i = 0; i < attempts; i++) {
			int x = x0 + random.nextInt(16);
			int z = z0 + random.nextInt(16);
			int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
			BlockPos pos = new BlockPos(x, y, z);
			if (!level.getBiome(pos).is(ModWorldgen.REPTILE_SWAMP)) {
				continue;
			}
			if (!level.getBlockState(pos).isAir() || !level.getBlockState(pos.below()).is(BlockTags.DIRT)) {
				continue;
			}
			Plant plant = pool.get(random.nextInt(pool.size()));
			if (plant.tall()) {
				if (!level.getBlockState(pos.above()).isAir()) {
					continue;
				}
				DoublePlantBlock.placeAt(level, plant.block().defaultBlockState(), pos, 2);
			} else {
				level.setBlock(pos, plant.block().defaultBlockState(), 2);
			}
		}
	}

	private ReptileFlora() {}
}
