package com.reptilia.world;

import com.reptilia.Reptilia;
import com.reptilia.entity.ModEntityTypes;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

/** Ciénaga Reptil: variante tropical del pantano donde viven todos los reptiles. */
public final class ModWorldgen {
	public static final ResourceKey<Biome> REPTILE_SWAMP =
			ResourceKey.create(Registries.BIOME, Reptilia.id("reptile_swamp"));

	public static final ReptileFloraFeature FLORA_FEATURE = new ReptileFloraFeature();

	public static void initialize() {
		Registry.register(BuiltInRegistries.FEATURE, Reptilia.id("reptile_flora"), FLORA_FEATURE);
		// La colocacion del bioma en el Overworld la hace OverworldBiomeBuilderMixin
		// Aparicion alta, como cerdos o vacas en una planicie (peso ~10 y grupos de 2-4).
		// La titanoboa es un miniboss: aparece, pero bastante menos.
		spawn(ModEntityTypes.IGUANA, 12, 2, 4);
		spawn(ModEntityTypes.GECKO, 12, 2, 5);
		spawn(ModEntityTypes.CAIMAN, 10, 1, 3);
		spawn(ModEntityTypes.NILE_CROCODILE, 8, 1, 2);
		spawn(ModEntityTypes.ALLIGATOR, 8, 1, 3);
		spawn(ModEntityTypes.RATTLESNAKE, 8, 1, 2);
		spawn(ModEntityTypes.ANACONDA, 6, 1, 2);
		spawn(ModEntityTypes.KING_COBRA, 6, 1, 2);
		spawn(ModEntityTypes.BLACK_MAMBA, 6, 1, 2);
		spawn(ModEntityTypes.TITANOBOA, 2, 1, 1);
	}

	private static void spawn(EntityType<?> type, int weight, int min, int max) {
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(REPTILE_SWAMP, Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
				MobCategory.CREATURE, type, weight, min, max);
	}

	private ModWorldgen() {}
}
