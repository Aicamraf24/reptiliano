package com.reptilia.world;

import com.reptilia.Reptilia;
import com.reptilia.entity.ModEntityTypes;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

/** Ciénaga Reptil: variante tropical del pantano donde viven todos los reptiles. */
public final class ModWorldgen {
	public static final ResourceKey<Biome> REPTILE_SWAMP =
			ResourceKey.create(Registries.BIOME, Reptilia.id("reptile_swamp"));

	public static void initialize() {
		addSwampVariant();

		spawn(ModEntityTypes.IGUANA, 14, 2, 4);
		spawn(ModEntityTypes.GECKO, 14, 2, 5);
		spawn(ModEntityTypes.ANACONDA, 8, 1, 2);
		spawn(ModEntityTypes.KING_COBRA, 6, 1, 1);
		spawn(ModEntityTypes.RATTLESNAKE, 6, 1, 2);
		spawn(ModEntityTypes.BLACK_MAMBA, 5, 1, 1);
		spawn(ModEntityTypes.CAIMAN, 8, 1, 3);
		spawn(ModEntityTypes.ALLIGATOR, 6, 1, 2);
		spawn(ModEntityTypes.NILE_CROCODILE, 5, 1, 2);
		spawn(ModEntityTypes.TITANOBOA, 1, 1, 1); // miniboss: muy raro

		// Algunos reptiles pequenos tambien en los pantanos y manglares normales
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
				MobCategory.CREATURE, ModEntityTypes.IGUANA, 4, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
				MobCategory.CREATURE, ModEntityTypes.CAIMAN, 3, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE),
				MobCategory.CREATURE, ModEntityTypes.GECKO, 4, 1, 3);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE),
				MobCategory.CREATURE, ModEntityTypes.IGUANA, 3, 1, 2);
	}

	/**
	 * Hace que la Ciénaga Reptil reemplace parte de los pantanos del Overworld usando la API de biomas de Fabric
	 * (OverworldBiomes.addBiomeVariant). Se llama por reflexion: si esa API cambia de firma en tu version, el mod
	 * no deja de compilar ni de cargar; solo avisa en el log y el bioma sigue disponible con /fillbiome.
	 */
	private static void addSwampVariant() {
		try {
			Class<?> api = Class.forName("net.fabricmc.fabric.api.biome.v1.OverworldBiomes");
			for (Method m : api.getMethods()) {
				if (!m.getName().equals("addBiomeVariant") || !Modifier.isStatic(m.getModifiers())) continue;
				Class<?>[] types = m.getParameterTypes();
				if (types.length < 3 || !types[0].isAssignableFrom(ResourceKey.class)) continue;
				Object[] args = new Object[types.length];
				args[0] = Biomes.SWAMP;
				args[1] = REPTILE_SWAMP;
				args[2] = 0.7D;
				if (types.length == 4 && types[3].isArray()) {
					args[3] = Array.newInstance(types[3].getComponentType(), 0);
				}
				m.invoke(null, args);
				Reptilia.LOGGER.info("Ciénaga Reptil registrada como variante del pantano");
				return;
			}
			Reptilia.LOGGER.warn("OverworldBiomes.addBiomeVariant no esta disponible: la Cienaga Reptil no generara sola");
		} catch (Throwable t) {
			Reptilia.LOGGER.warn("No se pudo registrar la variante de bioma (la Cienaga Reptil no generara sola)", t);
		}
	}

	private static void spawn(EntityType<?> type, int weight, int min, int max) {
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(REPTILE_SWAMP),
				MobCategory.CREATURE, type, weight, min, max);
	}

	private ModWorldgen() {}
}
