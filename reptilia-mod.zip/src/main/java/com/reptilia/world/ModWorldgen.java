package com.reptilia.world;

import com.reptilia.Reptilia;
import com.reptilia.entity.ModEntityTypes;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

/** Ciénaga Reptil: variante tropical del pantano donde viven todos los reptiles. */
public final class ModWorldgen {
	public static final ResourceKey<Biome> REPTILE_SWAMP =
			ResourceKey.create(Registries.BIOME, Reptilia.id("reptile_swamp"));

	public static final ReptileFloraFeature FLORA_FEATURE = new ReptileFloraFeature();

	public static void initialize() {
		Registry.register(BuiltInRegistries.FEATURE, Reptilia.id("reptile_flora"), FLORA_FEATURE);
		// La colocacion del bioma en el Overworld la hace OverworldBiomeBuilderMixin
		spawn(ModEntityTypes.IGUANA, 14, 2, 4);
		spawn(ModEntityTypes.GECKO, 14, 2, 5);
		spawn(ModEntityTypes.ANACONDA, 8, 1, 2);
		spawn(ModEntityTypes.KING_COBRA, 6, 1, 1);
		spawn(ModEntityTypes.RATTLESNAKE, 6, 1, 2);
		spawn(ModEntityTypes.BLACK_MAMBA, 5, 1, 1);
		spawn(ModEntityTypes.CAIMAN, 8, 1, 3);
		spawn(ModEntityTypes.ALLIGATOR, 6, 1, 2);
		spawn(ModEntityTypes.NILE_CROCODILE, 5, 1, 2);
		spawn(ModEntityTypes.TITANOBOA, 1, 1, 1); // miniboss: muy raro

		// Algunos reptiles pequenos tambien en los pantanos y manglares normales
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
				MobCategory.CREATURE, ModEntityTypes.IGUANA, 4, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
				MobCategory.CREATURE, ModEntityTypes.CAIMAN, 3, 1, 2);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE),
				MobCategory.CREATURE, ModEntityTypes.GECKO, 4, 1, 3);
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.JUNGLE, Biomes.SPARSE_JUNGLE, Biomes.BAMBOO_JUNGLE),
				MobCategory.CREATURE, ModEntityTypes.IGUANA, 3, 1, 2);
	}

	private static void spawn(EntityType<?> type, int weight, int min, int max) {
		BiomeModifications.addSpawn(BiomeSelectors.includeByKey(REPTILE_SWAMP),
				MobCategory.CREATURE, type, weight, min, max);
	}

	private ModWorldgen() {}
}
